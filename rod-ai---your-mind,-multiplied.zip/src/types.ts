export interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  image?: {
    data: string; // base64 or url
    mimeType: string;
    previewUrl?: string;
  };
  generatedImageUrl?: string;
  generatedVideoUrl?: string;
  suggestions?: string[];
  mode?: 'chat' | 'image' | 'video';
  isGenerating?: boolean;
}

export interface DailyUsage {
  date: string; // YYYY-MM-DD
  used: number; // 0 to 10
  bonusEarned: number;
}

export type AppView = 'chat' | 'landing';

export type InputMode = 'chat' | 'image' | 'video';

export interface DailyRequestItem {
  id: string;
  prompt: string;
  mode: InputMode;
  timestamp: number;
  status: 'completed' | 'in_progress' | 'failed';
  isGuest: boolean;
  requestIndex: number; // 1 to 10
  tierLabel: string; // 'Guest Free (1-3)' | 'Member Unlocked (4-10)' | 'Bonus Ad Request'
  error?: string;
  previewImageUrl?: string;
}

export interface DailyQuotaStatus {
  used: number; // requests used today
  effectiveLimit: number; // 3 for guest, 10 for member (+ bonus)
  guestLimit: number; // 3
  memberLimit: number; // 10
  remaining: number;
  isAuthenticated: boolean;
  requiresSignUpForRemaining: boolean; // true if guest hit 3 requests
  unlockedRequestsOnSignUp: number; // 7 (or 10 - used)
  bonusEarned: number;
  remainingBonusAds: number;
  canWatchAdForBonus: boolean;
  isCompletelyExhausted: boolean;
  date: string;
}
