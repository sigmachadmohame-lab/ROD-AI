import React, { useState } from 'react';
import {
  X,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Check,
  CreditCard,
  Smartphone,
  Wallet,
  ShieldCheck,
  RefreshCw,
  Globe,
} from 'lucide-react';
import { RodLogo } from './RodLogo.tsx';
import { useAuth } from '../context/AuthContext.tsx';

interface GooglePlayPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: 'standard' | 'pro';
  cycle: 'monthly' | 'annual';
  onSuccess?: () => void;
}

export interface PaymentMethodOption {
  id: string;
  nameAr: string;
  nameEn: string;
  type: 'carrier' | 'gpay' | 'balance' | 'card';
  iconColor: string;
  detailsAr?: string;
  detailsEn?: string;
}

const AVAILABLE_PAYMENT_METHODS: PaymentMethodOption[] = [
  {
    id: 'zain_iraq',
    nameAr: 'زين العراق / oodi / Zain Iraq',
    nameEn: 'Zain Iraq / oodi (Carrier Billing)',
    type: 'carrier',
    iconColor: '#00875a',
    detailsAr: 'خصم مباشر من رصيد الشريحة أو الفاتورة',
    detailsEn: 'Direct carrier billing from SIM balance',
  },
  {
    id: 'google_pay',
    nameAr: 'Google Pay (الحساب المتصل)',
    nameEn: 'Google Pay (Connected Account)',
    type: 'gpay',
    iconColor: '#1a73e8',
    detailsAr: 'متصل مع بطاقتك المحفوظة في Google',
    detailsEn: 'Linked to your saved cards in Google',
  },
  {
    id: 'play_balance',
    nameAr: 'رصيد Google Play (25.00$ متاح)',
    nameEn: 'Google Play Balance ($25.00 available)',
    type: 'balance',
    iconColor: '#01875f',
    detailsAr: 'بطاقات هدايا ورصيد متجر Google Play',
    detailsEn: 'Gift cards & promotional Google Play balance',
  },
  {
    id: 'credit_card',
    nameAr: 'Mastercard •••• 5842',
    nameEn: 'Mastercard •••• 5842',
    type: 'card',
    iconColor: '#ea4335',
    detailsAr: 'صالحة حتى 08/29',
    detailsEn: 'Expires 08/29',
  },
];

export const GooglePlayPaymentModal: React.FC<GooglePlayPaymentModalProps> = ({
  isOpen,
  onClose,
  plan,
  cycle,
  onSuccess,
}) => {
  const { user, loginWithGoogle, updateSubscription } = useAuth();
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethodOption>(
    AVAILABLE_PAYMENT_METHODS[0]
  );
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSubscribedSuccess, setIsSubscribedSuccess] = useState(false);
  const [gpaId, setGpaId] = useState('');

  if (!isOpen) return null;

  // Prices
  const isPro = plan === 'pro';
  const priceUsd =
    cycle === 'monthly' ? (isPro ? 10 : 5) : isPro ? 80 : 40;
  const cycleTextAr = cycle === 'monthly' ? 'شهريًا' : 'سنويًا';
  const cycleTextEn = cycle === 'monthly' ? 'month' : 'year';

  // Approximate IQD conversion for local carrier billing fidelity
  const priceIqd =
    cycle === 'monthly'
      ? isPro
        ? '13,000 د.ع.'
        : '6,500 د.ع.'
      : isPro
      ? '104,000 د.ع.'
      : '52,000 د.ع.';

  const handleSubscribe = async () => {
    setIsProcessing(true);

    try {
      // If user isn't logged in with Google, connect their account first
      let activeUser = user;
      if (!activeUser) {
        try {
          await loginWithGoogle();
        } catch {
          // If popup closed or aborted, continue with device Google Play account
        }
      }

      // Simulate authentic Google Play Billing transaction handshake
      await new Promise((r) => setTimeout(r, 1400));

      const generatedOrderId = `GPA.${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(
        1000 + Math.random() * 9000
      )}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(10000 + Math.random() * 90000)}`;
      setGpaId(generatedOrderId);

      const googleEmail =
        user?.email || 'sigmachadmohame@gmail.com';

      // Persist to Firestore and local state
      await updateSubscription(plan, cycle, selectedMethod.nameEn, googleEmail);

      setIsSubscribedSuccess(true);
      setTimeout(() => {
        setIsSubscribedSuccess(false);
        if (onSuccess) onSuccess();
        onClose();
      }, 2400);
    } catch (e) {
      console.error('Google Play subscription error:', e);
    } finally {
      setIsProcessing(false);
    }
  };

  const isRtl = lang === 'ar';

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200"
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      {/* Google Play Bottom Sheet / Dialog */}
      <div className="relative w-full max-w-lg bg-white text-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col font-sans transition-all">
        {/* Top Bar: Close, Google Play Logo, Language Toggle */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 bg-white sticky top-0 z-10">
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Authentic Google Play Header with 4-color Play Icon */}
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
              <path
                d="M3.609 1.814L13.792 12 3.61 22.186A2.28 2.28 0 0 1 3 20.573V3.427c0-.64.227-1.227.609-1.613z"
                fill="#00E676"
              />
              <path
                d="M17.18 8.614L13.792 12l3.388 3.386 3.824-2.193c.808-.464.808-1.722 0-2.186l-3.824-2.193z"
                fill="#FFD600"
              />
              <path
                d="M3.609 1.814l10.183 10.186 3.388-3.386L6.377.942C5.35.352 4.175.767 3.609 1.814z"
                fill="#00B0FF"
              />
              <path
                d="M3.609 22.186c.566 1.047 1.741 1.462 2.768.872l10.803-6.272-3.388-3.386L3.609 22.186z"
                fill="#FF3D00"
              />
            </svg>
            <span className="font-medium text-slate-800 text-lg tracking-tight">
              Google Play
            </span>
          </div>

          {/* Language Switcher */}
          <button
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            className="flex items-center gap-1 text-[11px] font-semibold text-slate-500 hover:text-slate-800 px-2 py-1 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto px-5 py-4 space-y-4">
          {/* Budget notice banner from screenshot */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-[#fff8e7] border border-[#fde4ad] text-[#855700] text-xs">
            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <p className="font-semibold">
                {lang === 'ar'
                  ? 'لقد تجاوزت ميزانيتك التي ستتم إعادة تعيينها في 2026/11/01.'
                  : 'You have exceeded your monthly budget which resets on 2026/11/01.'}
              </p>
            </div>
          </div>

          {/* Product Header Row matching Screenshot */}
          <div className="flex items-start justify-between gap-4 pt-1">
            <div className="min-w-0">
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 leading-tight">
                {lang === 'ar'
                  ? isPro
                    ? 'اشتراك برو بريميوم (Pro)'
                    : 'اشتراك ستاندرد (Standard)'
                  : isPro
                  ? 'Pro Premium Subscription'
                  : 'Standard Subscription'}
              </h2>
              <p className="text-slate-600 text-sm mt-1">
                ROD AI · Your Mind , Multiplied
              </p>
            </div>

            {/* App Icon badge matching Nova square in screenshot */}
            <div className="w-13 h-13 rounded-2xl bg-[#091122] flex items-center justify-center p-2 shadow-md shrink-0 border border-slate-200">
              <RodLogo size="sm" glow={false} />
            </div>
          </div>

          {/* Price & Starting Period Row */}
          <div className="flex items-baseline justify-between pt-2 border-t border-slate-100 text-slate-900">
            <div className="flex flex-col">
              <span className="text-2xl font-black text-slate-900">
                ${priceUsd}.00
                <span className="text-sm font-normal text-slate-500">
                  /{cycleTextEn}
                </span>
              </span>
              <span className="text-xs text-slate-500 mt-0.5 font-medium">
                ({priceIqd} / {cycleTextAr})
              </span>
            </div>

            <span className="text-sm text-slate-600 font-medium">
              {lang === 'ar' ? 'بدءًا من اليوم' : 'Starting today'}
            </span>
          </div>

          {/* Tax included & Cancellation notice */}
          <div className="text-xs text-slate-500 space-y-1">
            <p className="flex items-center gap-1">
              <span>
                {lang === 'ar'
                  ? 'الاطلاع على الضريبة المضمّنة'
                  : 'See included taxes'}
              </span>
              <span className="text-[11px] text-slate-400">ⓘ</span>
            </p>
            <p className="leading-relaxed">
              {lang === 'ar'
                ? 'يمكنك الإلغاء في أي وقت في صفحة "الاشتراكات" على Google Play'
                : 'You can cancel anytime in Subscriptions on Google Play'}
            </p>
          </div>

          {/* Interactive Payment Method Selector Row from Screenshot */}
          <div className="border-t border-b border-slate-200 py-3 my-2">
            <button
              type="button"
              onClick={() => setIsPickerOpen(!isPickerOpen)}
              className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-50 transition-all cursor-pointer group"
            >
              {/* Left/Right Chevron depending on direction */}
              <div className="w-7 h-7 rounded-full bg-slate-100 group-hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors shrink-0">
                {isRtl ? (
                  <ChevronLeft className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </div>

              {/* Payment Method Name */}
              <div className="flex-1 px-3 text-start min-w-0">
                <p className="text-sm font-bold text-slate-900 truncate">
                  {lang === 'ar' ? selectedMethod.nameAr : selectedMethod.nameEn}
                </p>
                <p className="text-[11px] text-slate-500 truncate">
                  {lang === 'ar'
                    ? selectedMethod.detailsAr
                    : selectedMethod.detailsEn}
                </p>
              </div>

              {/* Method Icon matching green SIM card in screenshot */}
              <div
                className="w-9 h-7 rounded-md border flex items-center justify-center shrink-0 shadow-xs"
                style={{
                  borderColor: selectedMethod.iconColor + '60',
                  backgroundColor: selectedMethod.iconColor + '12',
                }}
              >
                {selectedMethod.type === 'carrier' && (
                  <Smartphone
                    className="w-4 h-4"
                    style={{ color: selectedMethod.iconColor }}
                  />
                )}
                {selectedMethod.type === 'gpay' && (
                  <span className="text-[11px] font-black text-blue-600">
                    GPay
                  </span>
                )}
                {selectedMethod.type === 'balance' && (
                  <Wallet
                    className="w-4 h-4"
                    style={{ color: selectedMethod.iconColor }}
                  />
                )}
                {selectedMethod.type === 'card' && (
                  <CreditCard
                    className="w-4 h-4"
                    style={{ color: selectedMethod.iconColor }}
                  />
                )}
              </div>
            </button>

            {/* Dropdown Method Picker */}
            {isPickerOpen && (
              <div className="mt-2 p-2 bg-slate-50 rounded-2xl border border-slate-200 space-y-1 animate-in fade-in duration-150">
                <p className="text-[11px] font-bold text-slate-500 px-2 py-1 uppercase tracking-wider">
                  {lang === 'ar'
                    ? 'اختر طريقة الدفع عبر Google'
                    : 'Choose Google payment method'}
                </p>
                {AVAILABLE_PAYMENT_METHODS.map((method) => {
                  const isSelected = method.id === selectedMethod.id;
                  return (
                    <button
                      key={method.id}
                      onClick={() => {
                        setSelectedMethod(method);
                        setIsPickerOpen(false);
                      }}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl transition-all text-start cursor-pointer ${
                        isSelected
                          ? 'bg-blue-50 border border-blue-200'
                          : 'hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                          style={{
                            backgroundColor: method.iconColor + '15',
                            color: method.iconColor,
                          }}
                        >
                          {method.type === 'carrier' && (
                            <Smartphone className="w-4 h-4" />
                          )}
                          {method.type === 'gpay' && (
                            <span className="text-[10px] font-black">G</span>
                          )}
                          {method.type === 'balance' && (
                            <Wallet className="w-4 h-4" />
                          )}
                          {method.type === 'card' && (
                            <CreditCard className="w-4 h-4" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-900 truncate">
                            {lang === 'ar' ? method.nameAr : method.nameEn}
                          </p>
                          <p className="text-[10px] text-slate-500 truncate">
                            {lang === 'ar' ? method.detailsAr : method.detailsEn}
                          </p>
                        </div>
                      </div>

                      {isSelected && (
                        <Check className="w-4 h-4 text-blue-600 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Google Play Connected Account Info */}
          <div className="flex items-center justify-between px-3 py-2 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-600">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                G
              </div>
              <span className="truncate font-medium text-slate-700">
                {user?.email || 'sigmachadmohame@gmail.com'}
              </span>
            </div>
            <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full shrink-0">
              {lang === 'ar' ? 'متصل بـ Google' : 'Connected'}
            </span>
          </div>

          {/* Authentic Google Play Terms & Legal Text from Screenshot */}
          <div className="text-[11px] leading-relaxed text-slate-500 space-y-2.5">
            <p>
              {lang === 'ar'
                ? 'يمكن أن تؤدي بعض العوامل إلى زيادة المبلغ النهائي، مثل تقلبات أسعار العملة، والرسوم المصرفية أو رسوم استخدام طريقة الدفع البديلة، والضرائب السارية التي يحصّلها كل من البائع ومشغّل شبكة الجوّال. الاطلاع على أحكام وشروط مشغّل شبكة الجوّال.'
                : 'Factors such as currency fluctuations, banking fees, or alternative payment method fees, and applicable taxes collected by the merchant and mobile network operator may affect the final amount. See carrier terms and conditions.'}
            </p>
            <p>
              {lang === 'ar'
                ? 'عند النقر على "اشتراك"، فإن هذا يعني موافقتك على تجديد اشتراكك تلقائيًا إلى أن يتم إلغاؤه. سنُعلمك في حال تغيّر السعر، وذلك استنادًا لما هو موضّح في بنود خدمة Google Play. يمكنك التعرّف على كيفية إلغاء الاشتراك.'
                : 'By tapping "Subscribe", you agree to automatic renewal until cancelled. You will be notified in advance of any price changes in accordance with the Google Play Terms of Service. Learn how to cancel subscriptions.'}
            </p>
          </div>

          {/* Success Banner */}
          {isSubscribedSuccess && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 flex items-center gap-3 animate-in zoom-in-95">
              <ShieldCheck className="w-7 h-7 text-emerald-600 shrink-0" />
              <div>
                <p className="font-bold text-sm">
                  {lang === 'ar'
                    ? 'تم تأكيد الاشتراك بنجاح!'
                    : 'Subscription Confirmed!'}
                </p>
                <p className="text-xs text-emerald-700">
                  {lang === 'ar'
                    ? `رقم العملية: ${gpaId} · تم تفعيل خطة ${plan.toUpperCase()} بلا إعلانات`
                    : `Order ID: ${gpaId} · ${plan.toUpperCase()} activated ad-free`}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Action Button matching Google Play Blue Button in Screenshot */}
        <div className="p-4 border-t border-slate-100 bg-white">
          <button
            onClick={handleSubscribe}
            disabled={isProcessing || isSubscribedSuccess}
            className="w-full py-3.5 px-4 rounded-full bg-[#01875f] hover:bg-[#00704f] active:bg-[#005a3f] text-white font-bold text-base transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
          >
            {isProcessing ? (
              <div className="flex items-center gap-2">
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>
                  {lang === 'ar'
                    ? 'جارٍ الاتصال بـ Google Play...'
                    : 'Connecting to Google Play...'}
                </span>
              </div>
            ) : isSubscribedSuccess ? (
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5" />
                <span>{lang === 'ar' ? 'تم الاشتراك' : 'Subscribed'}</span>
              </div>
            ) : (
              <span>{lang === 'ar' ? 'اشتراك' : 'Subscribe'}</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
