import React from 'react';
import {
  Search,
  History,
  Smartphone,
  Sparkles,
  Crown,
  ChevronRight,
  MessageSquare,
} from 'lucide-react';
import { RodLogo } from './RodLogo.tsx';
import { useAuth } from '../context/AuthContext.tsx';

interface LandingViewProps {
  onStartChat: () => void;
  remainingCredits: number;
}

export const LandingView: React.FC<LandingViewProps> = ({ onStartChat, remainingCredits }) => {
  const { user, openAuthModal, subscription, openSubscriptionModal } = useAuth();

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between items-center px-4 py-5 md:py-8 z-10 overflow-y-auto bg-gradient-to-b from-[#090e1f] via-[#060913] to-[#04060d]">
      {/* Top Navbar */}
      <header className="w-full max-w-3xl flex items-center justify-between pb-4 border-b border-white/5">
        <div className="flex items-center gap-2 cursor-pointer" onClick={onStartChat}>
          <RodLogo size="xs" glow={false} />
          <span className="font-extrabold tracking-wider text-white text-sm">ROD AI</span>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Golden Crown Subscription Button */}
          <button
            onClick={openSubscriptionModal}
            className="group flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 via-yellow-400/25 to-amber-500/20 hover:from-amber-500/35 hover:to-yellow-400/40 border border-amber-400/70 shadow-[0_0_15px_rgba(251,191,36,0.35)] transition-all cursor-pointer"
            title="Standard ($5/mo, $40/yr) & Pro ($10/mo, $80/yr) Plans"
          >
            <Crown className="w-4 h-4 text-amber-400 fill-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-xs font-black text-amber-300 tracking-wider uppercase">
              {subscription.active ? subscription.plan : 'Upgrade'}
            </span>
          </button>

          {/* User Sign In / Profile */}
          {user ? (
            <div className="flex items-center gap-1.5 bg-slate-900 border border-cyan-500/30 px-2.5 py-1 rounded-full text-xs text-slate-300">
              <span className="w-4 h-4 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center text-[10px] font-bold">
                {user.displayName ? user.displayName[0].toUpperCase() : 'U'}
              </span>
              <span className="max-w-[70px] truncate text-[11px] font-medium hidden sm:inline">
                {user.displayName || user.email?.split('@')[0]}
              </span>
            </div>
          ) : (
            <button
              onClick={() => openAuthModal('login')}
              className="text-xs font-semibold px-3 py-1.5 rounded-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 transition-all cursor-pointer"
            >
              Sign In
            </button>
          )}

          <button
            onClick={onStartChat}
            className="text-xs font-bold bg-[#00a6f4] hover:bg-[#0095dc] text-white px-4 py-1.5 rounded-full transition-all shadow-[0_0_15px_rgba(0,166,244,0.35)] cursor-pointer flex items-center gap-1"
          >
            <span>Start Chat</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Main Showcase Hero matching User's Exact Screenshot */}
      <div className="w-full max-w-xl flex flex-col items-center text-center my-auto py-6 sm:py-8">
        {/* Pure Logo Emblem with glowing ambient aura - no background box */}
        <div className="flex flex-col items-center">
          <RodLogo size="lg" glow={true} />

          {/* ROD AI header */}
          <h2 className="mt-6 text-3xl sm:text-4xl font-black tracking-wide flex items-center justify-center gap-2">
            <span className="text-white">ROD</span>
            <span className="bg-gradient-to-r from-violet-400 to-indigo-400 bg-clip-text text-transparent">
              AI
            </span>
          </h2>

          {/* Subtitle from Screenshot */}
          <p className="mt-4 max-w-md text-slate-400 text-xs sm:text-sm leading-relaxed px-4">
            The next generation of intelligent chat. Instant responses, real-time web search, and a beautiful interface designed for your flow.
          </p>
        </div>

        {/* Feature Cards matching Screenshot */}
        <div className="w-full flex flex-col gap-3 mt-8 text-left px-2">
          {/* Card 1: Real-time Search */}
          <div
            onClick={onStartChat}
            className="group relative bg-[#091124]/90 hover:bg-[#0d1833] border border-cyan-500/20 hover:border-cyan-400/50 rounded-2xl p-4 sm:p-5 transition-all duration-200 cursor-pointer shadow-lg flex items-start gap-4"
          >
            <div className="w-11 h-11 rounded-xl bg-[#071f3a] border border-cyan-700/60 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-105 transition-transform">
              <Search className="w-5 h-5 text-cyan-400" />
            </div>
            <div className="min-w-0">
              <h3 className="text-white font-bold text-sm sm:text-base mb-1">Real-time Search</h3>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                Access the latest information and instant answers from the web.
              </p>
            </div>
          </div>

          {/* Card 2: Smart History */}
          <div
            onClick={onStartChat}
            className="group relative bg-[#091124]/90 hover:bg-[#0d1833] border border-cyan-500/20 hover:border-cyan-400/50 rounded-2xl p-4 sm:p-5 transition-all duration-200 cursor-pointer shadow-lg flex items-start gap-4"
          >
            <div className="w-11 h-11 rounded-xl bg-[#071f3a] border border-cyan-700/60 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-105 transition-transform">
              <History className="w-5 h-5 text-cyan-400" />
            </div>
            <div className="min-w-0">
              <h3 className="text-white font-bold text-sm sm:text-base mb-1">Smart History</h3>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                Your conversations are synced and organized securely across devices.
              </p>
            </div>
          </div>

          {/* Card 3: True Mobile */}
          <div
            onClick={onStartChat}
            className="group relative bg-[#091124]/90 hover:bg-[#0d1833] border border-cyan-500/20 hover:border-cyan-400/50 rounded-2xl p-4 sm:p-5 transition-all duration-200 cursor-pointer shadow-lg flex items-start gap-4"
          >
            <div className="w-11 h-11 rounded-xl bg-[#071f3a] border border-cyan-700/60 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-105 transition-transform">
              <Smartphone className="w-5 h-5 text-cyan-400" />
            </div>
            <div className="min-w-0">
              <h3 className="text-white font-bold text-sm sm:text-base mb-1">True Mobile</h3>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                Pixel-perfect fluid design optimized for desktop and mobile screens.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Launch Bar */}
        <div className="w-full flex flex-col items-center gap-3 mt-7">
          <button
            onClick={onStartChat}
            className="w-full max-w-sm cursor-pointer group relative inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-[#00a6f4] hover:bg-[#0095dc] text-white font-black text-sm sm:text-base shadow-[0_0_30px_rgba(0,166,244,0.45)] hover:shadow-[0_0_40px_rgba(0,166,244,0.65)] hover:scale-[1.01] active:scale-[0.98] transition-all duration-200 gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Open ROD AI Chat</span>
          </button>

          <p className="text-slate-500 text-xs tracking-wide">
            {remainingCredits} daily questions available · Watch real sponsor ad to unlock each answer
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="w-full text-center py-3 border-t border-white/5">
        <p className="text-[11px] font-semibold tracking-[0.25em] text-slate-600 uppercase">
          ROD AI · YOUR MIND , MULTIPLIED
        </p>
      </footer>
    </div>
  );
};
