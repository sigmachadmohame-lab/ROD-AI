import React, { useState } from 'react';

interface RodLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'emblem' | 'full';
  showText?: boolean;
  showSlogan?: boolean;
  className?: string;
  glow?: boolean;
}

export const RodLogo: React.FC<RodLogoProps> = ({
  size = 'md',
  variant = 'emblem',
  showText = false,
  showSlogan = false,
  className = '',
  glow = true,
}) => {
  const [imgError, setImgError] = useState(false);

  // Size mapping for the circular logo emblem
  const sizeMap = {
    xs: { box: 'w-7 h-7', font: 'text-xs', slogan: 'text-[8px]', glowSize: 'w-8 h-8' },
    sm: { box: 'w-9 h-9', font: 'text-sm', slogan: 'text-[9px]', glowSize: 'w-10 h-10' },
    md: { box: 'w-14 h-14', font: 'text-xl', slogan: 'text-[10px]', glowSize: 'w-16 h-16' },
    lg: { box: 'w-24 h-24 sm:w-28 sm:h-28', font: 'text-3xl', slogan: 'text-xs', glowSize: 'w-32 h-32' },
    xl: { box: 'w-32 h-32 sm:w-40 sm:h-40', font: 'text-4xl', slogan: 'text-sm', glowSize: 'w-44 h-44' },
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`relative flex flex-col items-center justify-center select-none ${className}`}>
      {/* Ambient soft cyan glow behind the logo */}
      {glow && (
        <div
          aria-hidden="true"
          className={`absolute rounded-full bg-cyan-400/25 blur-2xl pointer-events-none ${currentSize.glowSize}`}
        />
      )}

      {/* Pure Logo Emblem - transparent, no blue background box */}
      <div className={`relative ${currentSize.box} flex items-center justify-center`}>
        {!imgError ? (
          <img
            src="/assets/rod-emblem.png?v=3"
            alt="ROD Logo"
            onError={() => setImgError(true)}
            className="w-full h-full object-contain select-none pointer-events-none drop-shadow-[0_0_16px_rgba(56,189,248,0.45)] transition-transform duration-300 hover:scale-105"
          />
        ) : (
          <div className="w-full h-full rounded-full bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center font-black text-white text-2xl shadow-[0_0_20px_rgba(34,211,238,0.5)]">
            R
          </div>
        )}
      </div>

      {/* Optional typography if explicitly requested */}
      {(variant === 'full' || showText) && (
        <div className="mt-3 flex flex-col items-center text-center">
          <span className={`font-black tracking-[0.2em] text-white ${currentSize.font} uppercase drop-shadow-[0_2px_10px_rgba(255,255,255,0.2)]`}>
            ROD
          </span>
          {(variant === 'full' || showSlogan) && (
            <span className={`mt-1 font-bold tracking-[0.25em] text-sky-400 uppercase ${currentSize.slogan}`}>
              YOUR MIND , MULTIPLIED
            </span>
          )}
        </div>
      )}
    </div>
  );
};

