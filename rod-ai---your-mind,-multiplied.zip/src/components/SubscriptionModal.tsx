import React, { useState } from 'react';
import {
  X,
  Crown,
  Check,
  Sparkles,
  Zap,
  Shield,
  CreditCard,
  CheckCircle2,
  ArrowRight,
  Smartphone,
  Wallet,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { GooglePlayPaymentModal } from './GooglePlayPaymentModal.tsx';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export type SubscriptionPlan = 'standard' | 'pro';
export type BillingCycle = 'monthly' | 'annual';

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { user, subscription, openAuthModal } = useAuth();
  const [billingCycle, setBillingCycle] = useState<BillingCycle>('annual');
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan>('pro');
  const [isGooglePlayOpen, setIsGooglePlayOpen] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const pricing = {
    standard: {
      monthly: 5,
      annual: 40,
      annualPerMonth: '3.33',
      savings: 'Save $20/yr',
    },
    pro: {
      monthly: 10,
      annual: 80,
      annualPerMonth: '6.67',
      savings: 'Save $40/yr',
    },
  };

  const handleOpenGooglePlay = () => {
    setIsGooglePlayOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#090e1d] border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-[0_0_60px_rgba(245,158,11,0.2)] overflow-hidden max-h-[95vh] overflow-y-auto">
        {/* Golden ambient lighting */}
        <div className="absolute -top-24 -left-24 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 shadow-[0_0_25px_rgba(251,191,36,0.5)] mb-3">
            <div className="w-full h-full bg-[#0b1224] rounded-2xl flex items-center justify-center text-amber-400">
              <Crown className="w-8 h-8 fill-amber-400 stroke-amber-300 animate-pulse" />
            </div>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Upgrade Your Mind Power
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-md">
            Unlock unlimited questions, ultra-fast image generation, and multi-modal analysis with ROD AI.
          </p>

          {/* Billing Cycle Toggle */}
          <div className="inline-flex items-center p-1 bg-slate-900 border border-slate-800 rounded-full mt-5">
            <button
              type="button"
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly
            </button>
            <button
              type="button"
              onClick={() => setBillingCycle('annual')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all ${
                billingCycle === 'annual'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Annual</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-1.5 py-0.2 rounded-full border border-emerald-500/40">
                Save 33%
              </span>
            </button>
          </div>
        </div>

        {/* Success Banner */}
        {isSuccess && (
          <div className="mb-6 p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 flex items-center justify-center gap-3 animate-in zoom-in-95">
            <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
            <div className="text-left">
              <p className="font-bold text-sm">Subscription Activated!</p>
              <p className="text-xs text-emerald-200/80">
                You now have full access to {selectedPlan.toUpperCase()} features.
              </p>
            </div>
          </div>
        )}

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Standard Plan */}
          <div
            onClick={() => setSelectedPlan('standard')}
            className={`relative rounded-2xl p-5 border cursor-pointer transition-all ${
              selectedPlan === 'standard'
                ? 'bg-slate-900/90 border-cyan-400/60 shadow-[0_0_25px_rgba(34,211,238,0.2)]'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="font-bold text-base text-white">Standard</h3>
                <p className="text-xs text-slate-400">For daily personal productivity</p>
              </div>
              <div
                className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                  selectedPlan === 'standard'
                    ? 'border-cyan-400 bg-cyan-400 text-slate-950'
                    : 'border-slate-700'
                }`}
              >
                {selectedPlan === 'standard' && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
            </div>

            <div className="my-4">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-black text-white">
                  ${billingCycle === 'monthly' ? pricing.standard.monthly : pricing.standard.annual}
                </span>
                <span className="text-xs text-slate-400">
                  /{billingCycle === 'monthly' ? 'month' : 'year'}
                </span>
              </div>
              {billingCycle === 'annual' && (
                <p className="text-[11px] text-cyan-400 font-semibold mt-0.5">
                  ${pricing.standard.annualPerMonth}/mo • {pricing.standard.savings}
                </p>
              )}
            </div>

            <ul className="space-y-2 text-xs text-slate-300 border-t border-slate-800 pt-3">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>100 questions daily</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Multimodal image analysis</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Ad-free experience</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Cloud sync across devices</span>
              </li>
            </ul>
          </div>

          {/* Pro Plan */}
          <div
            onClick={() => setSelectedPlan('pro')}
            className={`relative rounded-2xl p-5 border cursor-pointer transition-all ${
              selectedPlan === 'pro'
                ? 'bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-900 border-amber-400/80 shadow-[0_0_30px_rgba(251,191,36,0.25)]'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            {/* Best Value Badge */}
            <div className="absolute -top-3 right-4 bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 font-black text-[10px] tracking-wider uppercase px-2.5 py-0.5 rounded-full shadow-md">
              Most Popular
            </div>

            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                <div>
                  <h3 className="font-bold text-base text-white">Pro</h3>
                  <p className="text-xs text-slate-400">For power creators & pros</p>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                  selectedPlan === 'pro'
                    ? 'border-amber-400 bg-amber-400 text-slate-950'
                    : 'border-slate-700'
                }`}
              >
                {selectedPlan === 'pro' && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
            </div>

            <div className="my-4">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-black text-white">
                  ${billingCycle === 'monthly' ? pricing.pro.monthly : pricing.pro.annual}
                </span>
                <span className="text-xs text-slate-400">
                  /{billingCycle === 'monthly' ? 'month' : 'year'}
                </span>
              </div>
              {billingCycle === 'annual' && (
                <p className="text-[11px] text-amber-400 font-semibold mt-0.5">
                  ${pricing.pro.annualPerMonth}/mo • {pricing.pro.savings}
                </p>
              )}
            </div>

            <ul className="space-y-2 text-xs text-slate-300 border-t border-slate-800 pt-3">
              <li className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-semibold text-white">Unlimited daily questions</span>
              </li>
              <li className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-semibold text-white">Unlimited high-accuracy photos</span>
              </li>
              <li className="flex items-center gap-2">
                <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Priority Ultra GPU processing</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Deep OCR & diagram extraction</span>
              </li>
              <li className="flex items-center gap-2">
                <Shield className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>24/7 VIP priority support</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Current status if already subscribed */}
        {subscription?.active && (
          <div className="mb-4 p-3 bg-slate-900 border border-emerald-500/40 rounded-xl text-center text-xs text-slate-300">
            <span className="text-emerald-400 font-bold">Active Subscription: </span>
            <strong className="text-amber-400 uppercase">{subscription.plan}</strong> (
            {subscription.cycle}) • Connected via{' '}
            <span className="text-cyan-300 font-semibold">{subscription.paymentMethod || 'Google Play'}</span>
          </div>
        )}

        {/* Google Payment Methods Badge Row */}
        <div className="mb-4 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            {/* Google Play Triangle */}
            <div className="w-6 h-6 rounded-md bg-white flex items-center justify-center p-0.5 shadow-xs">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
                <path d="M3.609 1.814L13.792 12 3.61 22.186A2.28 2.28 0 0 1 3 20.573V3.427c0-.64.227-1.227.609-1.613z" fill="#00E676" />
                <path d="M17.18 8.614L13.792 12l3.388 3.386 3.824-2.193c.808-.464.808-1.722 0-2.186l-3.824-2.193z" fill="#FFD600" />
                <path d="M3.609 1.814l10.183 10.186 3.388-3.386L6.377.942C5.35.352 4.175.767 3.609 1.814z" fill="#00B0FF" />
                <path d="M3.609 22.186c.566 1.047 1.741 1.462 2.768.872l10.803-6.272-3.388-3.386L3.609 22.186z" fill="#FF3D00" />
              </svg>
            </div>
            <div>
              <p className="font-bold text-white leading-tight">Google Play Billing</p>
              <p className="text-[11px] text-slate-400">Connected with your Google Account</p>
            </div>
          </div>

          {/* Supported Methods Tags */}
          <div className="flex items-center gap-1.5 flex-wrap justify-center sm:justify-end">
            <span className="px-2 py-0.5 rounded-md bg-emerald-950/60 border border-emerald-600/40 text-[10px] font-bold text-emerald-400">
              زين العراق / oodi
            </span>
            <span className="px-2 py-0.5 rounded-md bg-blue-950/60 border border-blue-600/40 text-[10px] font-bold text-blue-400">
              Google Pay
            </span>
            <span className="px-2 py-0.5 rounded-md bg-amber-950/60 border border-amber-600/40 text-[10px] font-bold text-amber-400">
              Play Balance
            </span>
            <span className="px-2 py-0.5 rounded-md bg-slate-800 text-[10px] font-bold text-slate-300">
              Cards
            </span>
          </div>
        </div>

        {/* CTA Button */}
        <div className="flex flex-col gap-2">
          <button
            onClick={handleOpenGooglePlay}
            className="w-full py-3.5 px-4 rounded-full bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2.5 shadow-[0_0_25px_rgba(251,191,36,0.4)] hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer"
          >
            {/* Play triangle */}
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none">
              <path d="M3.609 1.814L13.792 12 3.61 22.186A2.28 2.28 0 0 1 3 20.573V3.427c0-.64.227-1.227.609-1.613z" fill="#00E676" />
              <path d="M17.18 8.614L13.792 12l3.388 3.386 3.824-2.193c.808-.464.808-1.722 0-2.186l-3.824-2.193z" fill="#FFD600" />
              <path d="M3.609 1.814l10.183 10.186 3.388-3.386L6.377.942C5.35.352 4.175.767 3.609 1.814z" fill="#00B0FF" />
              <path d="M3.609 22.186c.566 1.047 1.741 1.462 2.768.872l10.803-6.272-3.388-3.386L3.609 22.186z" fill="#FF3D00" />
            </svg>
            <span>
              Pay with Google Play — {selectedPlan.toUpperCase()} (
              {billingCycle === 'monthly'
                ? `$${selectedPlan === 'standard' ? pricing.standard.monthly : pricing.pro.monthly}/mo`
                : `$${selectedPlan === 'standard' ? pricing.standard.annual : pricing.pro.annual}/yr`}
              )
            </span>
            <ArrowRight className="w-4 h-4 stroke-[3]" />
          </button>

          <p className="text-center text-[11px] text-slate-400 flex items-center justify-center gap-2 pt-1">
            <Shield className="w-3 h-3 text-emerald-400" />
            <span>Connected with Google Account · Official Google Play Billing · Cancel anytime</span>
          </p>
        </div>
      </div>

      {/* Google Play Billing Bottom Sheet / Modal */}
      <GooglePlayPaymentModal
        isOpen={isGooglePlayOpen}
        onClose={() => setIsGooglePlayOpen(false)}
        plan={selectedPlan}
        cycle={billingCycle}
        onSuccess={() => {
          setIsGooglePlayOpen(false);
          setIsSuccess(true);
          setTimeout(() => {
            setIsSuccess(false);
            onClose();
          }, 1800);
        }}
      />
    </div>
  );
};
