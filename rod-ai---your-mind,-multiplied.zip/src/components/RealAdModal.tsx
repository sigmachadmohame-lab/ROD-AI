import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Play,
  CheckCircle2,
  Sparkles,
  Volume2,
  VolumeX,
  ExternalLink,
  ShieldCheck,
  Info,
  Crown,
  ChevronRight,
  Gift,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { addBonusQuestion, MAX_BONUS_ADS } from '../utils/storage.ts';

export interface AdCampaign {
  id: string;
  brand: string;
  domain: string;
  headline: string;
  tagline: string;
  ctaText: string;
  destinationUrl: string;
  rating: number;
  reviewCount: string;
  videoUrl: string;
  accentColor: string;
  category: string;
}

const REAL_AD_CAMPAIGNS: AdCampaign[] = [
  {
    id: 'google-pixel',
    brand: 'Google Store',
    domain: 'store.google.com/pixel',
    headline: 'Google Pixel 9 Pro with Gemini',
    tagline: 'The only phone engineered with Gemini AI built-in. Capture reality, edit the impossible.',
    ctaText: 'Explore Pixel 9 Pro',
    destinationUrl: 'https://store.google.com/category/phones',
    rating: 4.9,
    reviewCount: '34.8K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    accentColor: '#38bdf8',
    category: 'Technology & AI',
  },
  {
    id: 'nike-tech',
    brand: 'Nike Official',
    domain: 'nike.com/running',
    headline: 'Nike Pegasus Turbo · Responsive Energy Return',
    tagline: 'Engineered with ZoomX aerodynamic foam for explosive velocity and daily endurance.',
    ctaText: 'Shop Nike Collection',
    destinationUrl: 'https://www.nike.com',
    rating: 4.8,
    reviewCount: '19.2K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    accentColor: '#f43f5e',
    category: 'Athletics & Gear',
  },
  {
    id: 'spotify-premium',
    brand: 'Spotify AB',
    domain: 'spotify.com/premium',
    headline: 'Spotify Premium — Zero Interruption Sound',
    tagline: 'Over 100 million songs in lossless audio. Download music, listen offline, zero ads.',
    ctaText: 'Get 3 Months Free',
    destinationUrl: 'https://www.spotify.com',
    rating: 4.9,
    reviewCount: '62.4K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    accentColor: '#10b981',
    category: 'Music & Podcasts',
  },
  {
    id: 'audi-electric',
    brand: 'Audi Global',
    domain: 'audi.com/e-tron-gt',
    headline: 'Audi e-tron GT · Pure Electric Performance',
    tagline: 'Progressive electric architecture with 800-volt high-speed charging and dual-motor torque.',
    ctaText: 'Configure Yours',
    destinationUrl: 'https://www.audi.com',
    rating: 4.9,
    reviewCount: '11.5K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    accentColor: '#eab308',
    category: 'Automotive Electric',
  },
  {
    id: 'nvidia-ai',
    brand: 'NVIDIA Studio',
    domain: 'nvidia.com/geforce-rtx',
    headline: 'NVIDIA GeForce RTX · AI Workstation Power',
    tagline: 'Transform generative creativity with dedicated Tensor cores and ultra-fast neural rendering.',
    ctaText: 'Discover RTX AI',
    destinationUrl: 'https://www.nvidia.com',
    rating: 4.9,
    reviewCount: '48.1K',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    accentColor: '#22c55e',
    category: 'Hardware & Neural AI',
  },
];

interface RealAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdCompleted: () => void;
  mode?: 'bonus_offer' | 'question' | 'reward';
  remainingBonusAds?: number;
}

export const RealAdModal: React.FC<RealAdModalProps> = ({
  isOpen,
  onClose,
  onAdCompleted,
  mode = 'bonus_offer',
  remainingBonusAds = 3,
}) => {
  const { openSubscriptionModal } = useAuth();
  const [currentAdIndex, setCurrentAdIndex] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(5);
  const [isFinished, setIsFinished] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [showExitWarning, setShowExitWarning] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Pick a fresh ad on open
  useEffect(() => {
    if (isOpen) {
      const randomIdx = Math.floor(Math.random() * REAL_AD_CAMPAIGNS.length);
      setCurrentAdIndex(randomIdx);
      setSecondsLeft(5);
      setIsFinished(false);
      setShowExitWarning(false);
      setShowInfoModal(false);

      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().catch(() => {});
      }
    }
  }, [isOpen]);

  // 5-second countdown timer
  useEffect(() => {
    if (!isOpen || isFinished) return;

    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsFinished(true);
          playCompletionChime();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, isFinished]);

  // Sound chime upon completing ad
  const playCompletionChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15);

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch {
      // Audio not permitted or supported
    }
  };

  if (!isOpen) return null;

  const currentAd = REAL_AD_CAMPAIGNS[currentAdIndex];

  const handleFinishAndContinue = () => {
    onAdCompleted();
    onClose();
  };

  const handleAttemptClose = () => {
    if (isFinished) {
      handleFinishAndContinue();
    } else {
      setShowExitWarning(true);
    }
  };

  const toggleSound = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVisitAdvertiser = () => {
    window.open(currentAd.destinationUrl, '_blank', 'noopener,noreferrer');
  };

  const bonusOfferNumber = Math.min(MAX_BONUS_ADS, (MAX_BONUS_ADS - remainingBonusAds) + 1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#070b16] border border-cyan-500/40 rounded-3xl shadow-[0_0_60px_rgba(6,182,212,0.3)] overflow-hidden flex flex-col">
        {/* Top Real Ad Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0a1124] border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded flex items-center gap-1">
              <span>Offer Ad</span>
              <span className="text-amber-400">· {bonusOfferNumber} of 3</span>
            </span>

            <div className="flex items-center gap-1 text-slate-300 text-xs font-semibold">
              <span className="max-w-[120px] sm:max-w-none truncate">{currentAd.domain}</span>
              <span title="Verified Advertiser" className="inline-flex items-center">
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              </span>
            </div>

            <button
              onClick={() => setShowInfoModal(!showInfoModal)}
              className="text-slate-500 hover:text-slate-300 p-0.5"
              title="Why this ad?"
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Audio Toggle */}
            <button
              onClick={toggleSound}
              className="flex items-center gap-1 text-xs text-slate-300 bg-slate-800/80 hover:bg-slate-700/80 px-2.5 py-1 rounded-full transition-colors cursor-pointer"
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-[11px] font-medium hidden sm:inline">Unmute</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                  <span className="text-[11px] font-medium text-cyan-300 hidden sm:inline">Sound On</span>
                </>
              )}
            </button>

            {/* Close Button */}
            <button
              onClick={handleAttemptClose}
              className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition-colors cursor-pointer"
              title={isFinished ? 'Close' : 'Ad must finish to unlock bonus question'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Special Offer Header Banner */}
        <div className="bg-gradient-to-r from-cyan-950/70 via-blue-950/80 to-purple-950/70 px-4 py-2 border-b border-cyan-500/20 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
            <Gift className="w-4 h-4 text-cyan-400 animate-bounce" />
            <span>Special Offer: 1 Ad for 1 Question</span>
          </div>
          <span className="text-[11px] text-amber-300 font-semibold bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/30">
            {remainingBonusAds} of 3 available today
          </span>
        </div>

        {/* Info Dropdown */}
        {showInfoModal && (
          <div className="bg-[#0b162f] p-3 border-b border-cyan-500/30 text-xs text-slate-300 space-y-1 animate-in fade-in">
            <p className="font-bold text-white flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              1 Ad for 1 Question (3 times daily)
            </p>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              When you use your 10 free daily requests, ROD AI gives you an exclusive offer: watch 1 short 5-second sponsor ad to earn 1 bonus question, up to 3 times per day.
            </p>
            <button
              onClick={() => {
                setShowInfoModal(false);
                openSubscriptionModal();
              }}
              className="text-amber-300 hover:text-amber-200 font-bold text-[11px] flex items-center gap-1 pt-1"
            >
              <Crown className="w-3 h-3 text-amber-400" />
              Or go Pro for unlimited questions with zero ads
            </button>
          </div>
        )}

        {/* Video Commercial Player Area */}
        <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden group">
          <video
            ref={videoRef}
            src={currentAd.videoUrl}
            autoPlay
            playsInline
            loop
            muted={isMuted}
            className="w-full h-full object-cover"
          />

          {/* Top Left Floating Pill */}
          <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 text-white text-[11px] font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Sponsor Commercial</span>
          </div>

          {/* Top Right Countdown Timer Pill */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5 bg-black/75 backdrop-blur-md px-3 py-1 rounded-full border border-cyan-500/40 text-cyan-300 text-xs font-bold shadow-lg">
            {!isFinished ? (
              <span>Unlocks in <strong className="text-white font-extrabold">{secondsLeft}s</strong></span>
            ) : (
              <span className="text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>+1 Question Ready</span>
              </span>
            )}
          </div>

          {/* In-Video Overlay Card (Bottom banner) */}
          <div className="absolute bottom-0 inset-x-0 p-3 sm:p-4 bg-gradient-to-t from-black via-black/80 to-transparent flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-sm shadow-md shrink-0 border border-white/20"
                style={{ backgroundColor: currentAd.accentColor }}
              >
                {currentAd.brand[0]}
              </div>
              <div className="min-w-0">
                <h4 className="text-white font-bold text-xs sm:text-sm truncate leading-snug">
                  {currentAd.headline}
                </h4>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
                  <span className="text-amber-400 font-bold">★ {currentAd.rating}</span>
                  <span className="text-slate-400">({currentAd.reviewCount})</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-400 truncate">{currentAd.category}</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleVisitAdvertiser}
              className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 font-extrabold text-xs transition-all shadow-md cursor-pointer"
            >
              <span>{currentAd.ctaText}</span>
              <ExternalLink className="w-3 h-3 text-slate-900" />
            </button>
          </div>

          {/* Progress Bar Line */}
          <div className="absolute bottom-0 inset-x-0 h-1 bg-slate-800">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 via-sky-400 to-emerald-400 transition-all duration-1000 ease-linear"
              style={{ width: `${((5 - secondsLeft) / 5) * 100}%` }}
            />
          </div>
        </div>

        {/* Bottom Status & Unlock Area */}
        <div className="p-4 sm:p-5 flex flex-col gap-3 bg-[#080d1e]">
          <p className="text-xs text-slate-400 text-center leading-relaxed">
            You've completed your 10 free daily questions. Watching this 5-second sponsor ad grants <strong className="text-cyan-400 font-semibold">+1 Question & Photo</strong>!
          </p>

          {/* Action Button */}
          {isFinished ? (
            <button
              onClick={handleFinishAndContinue}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-500 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(6,182,212,0.5)] transition-all cursor-pointer animate-in zoom-in-95"
            >
              <CheckCircle2 className="w-4 h-4 text-slate-950" />
              <span>Claim +1 Question & Continue to ROD AI</span>
              <ChevronRight className="w-4 h-4 text-slate-950" />
            </button>
          ) : (
            <div className="w-full py-3 px-4 rounded-2xl bg-slate-800/80 border border-slate-700/60 text-slate-400 font-medium text-xs sm:text-sm flex items-center justify-center gap-2 select-none">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>Watch <strong className="text-cyan-300">{secondsLeft}s</strong> to unlock your +1 bonus question...</span>
            </div>
          )}

          {/* Remove Ads Upgrade Prompt with Golden Crown */}
          <div className="pt-1 flex items-center justify-center">
            <button
              onClick={() => {
                setShowExitWarning(false);
                openSubscriptionModal();
              }}
              className="group flex items-center gap-1.5 text-xs text-amber-300/90 hover:text-amber-200 transition-colors cursor-pointer"
            >
              <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400 group-hover:scale-110 transition-transform" />
              <span>Want unlimited answers? <strong className="underline underline-offset-2">Upgrade to ROD Pro</strong></span>
            </button>
          </div>
        </div>

        {/* Exit Early Warning Modal */}
        {showExitWarning && (
          <div className="absolute inset-0 z-20 bg-black/90 backdrop-blur-md flex items-center justify-center p-6 text-center animate-in fade-in">
            <div className="bg-[#0b1428] border border-amber-500/40 rounded-2xl p-5 max-w-sm w-full space-y-3 shadow-2xl">
              <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/30">
                <Gift className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-white text-base">
                Finish Watching for Your Bonus Question
              </h3>
              <p className="text-slate-300 text-xs leading-relaxed">
                Watch the remaining <strong className="text-cyan-400">{secondsLeft} seconds</strong> of this ad to unlock your +1 question offer ({remainingBonusAds} of 3 left today).
              </p>
              <div className="flex flex-col gap-2 pt-2">
                <button
                  onClick={() => setShowExitWarning(false)}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-bold text-xs shadow-md cursor-pointer"
                >
                  Keep Watching ({secondsLeft}s left)
                </button>
                <button
                  onClick={() => {
                    setShowExitWarning(false);
                    openSubscriptionModal();
                  }}
                  className="w-full py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-semibold text-xs transition-colors cursor-pointer"
                >
                  Upgrade to Pro (Unlimited Questions)
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Also export as AdRewardModal for backwards compatibility
export const AdRewardModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onRewardClaimed: (newRemaining: number) => void;
  remainingBonusAds?: number;
}> = ({ isOpen, onClose, onRewardClaimed, remainingBonusAds = 3 }) => {
  return (
    <RealAdModal
      isOpen={isOpen}
      onClose={onClose}
      mode="bonus_offer"
      remainingBonusAds={remainingBonusAds}
      onAdCompleted={() => {
        const result = addBonusQuestion();
        if (result.success) {
          onRewardClaimed(result.newRemaining);
        }
      }}
    />
  );
};
