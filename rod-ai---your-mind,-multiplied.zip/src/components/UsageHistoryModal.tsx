import React, { useState, useEffect } from 'react';
import {
  X,
  History,
  CheckCircle2,
  Clock,
  AlertCircle,
  MessageSquare,
  Image as ImageIcon,
  Film,
  Crown,
  User,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Copy,
  Check,
  Flame,
  ShieldCheck,
  Lock,
  Unlock,
} from 'lucide-react';
import { DailyRequestItem } from '../types.ts';
import {
  getDailyUsage,
  getDailyRequestHistory,
  GUEST_LIMIT,
  MEMBER_LIMIT,
  clearDailyHistory,
} from '../utils/storage.ts';
import { useAuth } from '../context/AuthContext.tsx';

interface UsageHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRerunPrompt?: (prompt: string, mode: 'chat' | 'image' | 'video') => void;
}

export const UsageHistoryModal: React.FC<UsageHistoryModalProps> = ({
  isOpen,
  onClose,
  onRerunPrompt,
}) => {
  const { user, openAuthModal, subscription, openSubscriptionModal } = useAuth();
  const [historyItems, setHistoryItems] = useState<DailyRequestItem[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [timeUntilReset, setTimeUntilReset] = useState<string>('');

  const isAuthenticated = !!user;
  const isSubscribed = subscription.active;
  const usage = getDailyUsage(isAuthenticated);

  // Load history and calculate reset countdown
  const loadData = () => {
    const items = getDailyRequestHistory();
    setHistoryItems(items);
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  // Countdown to midnight
  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const midnight = new Date();
      midnight.setHours(24, 0, 0, 0);
      const diffMs = midnight.getTime() - now.getTime();
      const hours = Math.floor(diffMs / (1000 * 60 * 60));
      const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      setTimeUntilReset(`${hours}h ${minutes}m`);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 60000);
    return () => clearInterval(interval);
  }, []);

  if (!isOpen) return null;

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearHistory = () => {
    if (window.confirm('Clear your daily request history for today?')) {
      clearDailyHistory();
      setHistoryItems([]);
    }
  };

  const formatTimestamp = (ts: number) => {
    const date = new Date(ts);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Quota counts
  const usedCount = usage.used;
  const guestMax = GUEST_LIMIT; // 3
  const memberMax = MEMBER_LIMIT; // 10
  const remainingForUser = usage.remaining;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[92vh] flex flex-col bg-[#080e1e] border border-cyan-500/30 rounded-3xl shadow-[0_0_50px_rgba(6,182,212,0.2)] overflow-hidden">
        {/* Top Header */}
        <div className="shrink-0 px-5 sm:px-6 py-4 flex items-center justify-between border-b border-slate-800 bg-[#0c152e]/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-base sm:text-lg">
                  Daily Usage & History
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                  Today
                </span>
              </div>
              <p className="text-slate-400 text-xs flex items-center gap-1.5 mt-0.5">
                <Clock className="w-3 h-3 text-cyan-400" />
                Resets at midnight in{' '}
                <strong className="text-white font-medium">{timeUntilReset}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto px-5 sm:px-6 py-4 space-y-5">
          {/* Quota Overview Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0c1733] to-[#070d1d] border border-slate-800 shadow-lg space-y-3.5">
            {/* Account Tier Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isSubscribed ? (
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold">
                    <Crown className="w-3.5 h-3.5 fill-amber-300" />
                    <span>ROD {subscription.plan.toUpperCase()} • Unlimited</span>
                  </div>
                ) : isAuthenticated ? (
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 text-xs font-semibold">
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Member Account • 10 Daily Requests</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700 text-xs font-semibold">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span>Guest Mode • 3 Initial Requests</span>
                  </div>
                )}
              </div>

              <div className="text-right">
                <span className="text-xs text-slate-400">Used today: </span>
                <span className="text-sm font-black text-cyan-400">
                  {usedCount}
                </span>
                <span className="text-xs text-slate-500">
                  /{isSubscribed ? '∞' : isAuthenticated ? memberMax : guestMax}
                </span>
              </div>
            </div>

            {/* Segmented 10-Request Progress Bar */}
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1.5 text-slate-400">
                <span className="flex items-center gap-1 font-medium">
                  <span className="text-cyan-400 font-bold">3</span> Guest Requests
                </span>
                <span className="flex items-center gap-1 font-medium">
                  {isAuthenticated ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <Unlock className="w-3 h-3" /> 7 Member Requests Unlocked
                    </span>
                  ) : (
                    <span className="text-amber-400 font-bold flex items-center gap-1">
                      <Lock className="w-3 h-3" /> 7 Unlocked Upon Sign-Up
                    </span>
                  )}
                </span>
              </div>

              {/* 10 Visual Request Slots */}
              <div className="grid grid-cols-10 gap-1 sm:gap-1.5 py-1">
                {Array.from({ length: 10 }).map((_, index) => {
                  const reqNum = index + 1;
                  const isUsed = reqNum <= usedCount;
                  const isGuestSlot = reqNum <= 3;
                  const isLockedForGuest = !isAuthenticated && !isGuestSlot;

                  return (
                    <div
                      key={reqNum}
                      className="group relative flex flex-col items-center"
                      title={
                        isUsed
                          ? `Request #${reqNum} completed`
                          : isLockedForGuest
                          ? `Request #${reqNum} (Sign up free to unlock!)`
                          : `Request #${reqNum} available`
                      }
                    >
                      <div
                        className={`w-full h-3 rounded-full transition-all ${
                          isUsed
                            ? 'bg-gradient-to-r from-cyan-400 to-blue-500 shadow-[0_0_8px_rgba(6,182,212,0.6)]'
                            : isLockedForGuest
                            ? 'bg-slate-800/80 border border-slate-700/60'
                            : 'bg-slate-700/60 border border-cyan-500/20'
                        }`}
                      />
                      <span className="text-[9px] text-slate-500 mt-1">
                        {reqNum}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Unlocked / Unlock CTA Banner */}
            {!isAuthenticated && (
              <div className="p-3 rounded-xl bg-gradient-to-r from-cyan-950/70 via-blue-950/60 to-slate-900 border border-cyan-500/40 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 text-left">
                  <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-300 shrink-0">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">
                      Unlock Remaining 7 Daily Requests
                    </h4>
                    <p className="text-[11px] text-slate-300">
                      Sign up for free now to get full 10 daily requests every day!
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onClose();
                    openAuthModal('signup');
                  }}
                  className="w-full sm:w-auto shrink-0 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 text-xs font-bold flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(6,182,212,0.4)] hover:brightness-110 transition-all cursor-pointer"
                >
                  <span>Sign Up (Free)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Bonus Ads Notice if 10 daily requests used */}
            {isAuthenticated && usedCount >= 10 && (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 flex items-center justify-between text-xs text-amber-200">
                <div className="flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    10 daily requests used! <strong>{usage.remainingBonusAds}</strong> bonus ad questions available (1 ad = 1 question).
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* List of Previous Daily Requests */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Previous Daily Requests ({historyItems.length})
              </h4>
              {historyItems.length > 0 && (
                <button
                  onClick={handleClearHistory}
                  className="text-[11px] text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                >
                  Clear History
                </button>
              )}
            </div>

            {historyItems.length === 0 ? (
              /* Empty state */
              <div className="p-8 rounded-2xl bg-[#091024]/60 border border-dashed border-slate-800 text-center space-y-2.5">
                <div className="w-10 h-10 rounded-full bg-slate-800/80 flex items-center justify-center mx-auto text-slate-500">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <h5 className="text-xs font-bold text-slate-300">
                  No requests recorded yet today
                </h5>
                <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                  Ask a question or generate an image in the chat to see your requests and real-time status tracked here.
                </p>
              </div>
            ) : (
              /* Request Items List */
              <div className="space-y-2.5">
                {historyItems.map((item, idx) => {
                  const isGuestRequest = item.isGuest || item.requestIndex <= 3;
                  const isBonus = item.requestIndex > 10;

                  return (
                    <div
                      key={item.id}
                      className="group p-3.5 rounded-2xl bg-[#091228] hover:bg-[#0c1836] border border-slate-800 hover:border-cyan-500/30 transition-all space-y-2"
                    >
                      {/* Top Row: Index, Mode, Status, Timestamp */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {/* Request Index Badge */}
                          <span className="px-2 py-0.5 rounded-md bg-cyan-950/80 border border-cyan-800/50 text-cyan-300 text-[10px] font-black">
                            #{item.requestIndex || historyItems.length - idx}
                          </span>

                          {/* Mode Icon & Label */}
                          <span className="flex items-center gap-1 text-[11px] font-semibold text-slate-300">
                            {item.mode === 'image' ? (
                              <>
                                <ImageIcon className="w-3.5 h-3.5 text-purple-400" />
                                <span>Image Gen</span>
                              </>
                            ) : item.mode === 'video' ? (
                              <>
                                <Film className="w-3.5 h-3.5 text-pink-400" />
                                <span>Video Gen</span>
                              </>
                            ) : (
                              <>
                                <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
                                <span>Chat</span>
                              </>
                            )}
                          </span>

                          {/* Tier Tag */}
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
                              isBonus
                                ? 'bg-amber-950/70 border-amber-600/40 text-amber-300'
                                : isGuestRequest
                                ? 'bg-slate-800 border-slate-700 text-slate-400'
                                : 'bg-emerald-950/70 border-emerald-600/40 text-emerald-300'
                            }`}
                          >
                            {isBonus
                              ? 'Bonus Ad'
                              : isGuestRequest
                              ? 'Guest'
                              : 'Member (Unlocked)'}
                          </span>
                        </div>

                        {/* Status Badge & Timestamp */}
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-500">
                            {formatTimestamp(item.timestamp)}
                          </span>

                          {item.status === 'completed' ? (
                            <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-500/30">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                              <span>Completed</span>
                            </span>
                          ) : item.status === 'in_progress' ? (
                            <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/30 animate-pulse">
                              <Clock className="w-3 h-3 text-cyan-400 animate-spin" />
                              <span>In Progress</span>
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-950/80 text-red-400 border border-red-500/30">
                              <AlertCircle className="w-3 h-3 text-red-400" />
                              <span>Failed</span>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Prompt Content */}
                      <p className="text-xs text-slate-200 line-clamp-2 leading-relaxed">
                        {item.prompt}
                      </p>

                      {/* Optional Image Preview thumbnail */}
                      {item.previewImageUrl && (
                        <div className="mt-1 w-16 h-16 rounded-lg overflow-hidden border border-slate-700">
                          <img
                            src={item.previewImageUrl}
                            alt="Generated visual"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}

                      {/* Action buttons */}
                      <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-800/60">
                        <button
                          onClick={() => handleCopy(item.id, item.prompt)}
                          className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2 py-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                        >
                          {copiedId === item.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy Prompt</span>
                            </>
                          )}
                        </button>

                        {onRerunPrompt && (
                          <button
                            onClick={() => {
                              onClose();
                              onRerunPrompt(item.prompt, item.mode);
                            }}
                            className="flex items-center gap-1 text-[11px] text-cyan-300 hover:text-cyan-200 px-2 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 transition-colors cursor-pointer font-medium"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Ask Again</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="shrink-0 px-5 sm:px-6 py-3 border-t border-slate-800 bg-[#0a1226] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>
              Total requests allowed: <strong>{isSubscribed ? 'Unlimited (PRO)' : isAuthenticated ? '10 / day' : '3 Guest (10 on sign up)'}</strong>
            </span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
