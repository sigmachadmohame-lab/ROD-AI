import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Plus,
  Image as ImageIcon,
  MessageSquare,
  Sparkles,
  RefreshCw,
  Copy,
  Check,
  X,
  Upload,
  User as UserIcon,
  LogOut,
  Maximize2,
  Download,
  AlertCircle,
  HelpCircle,
  Eye,
  Camera,
  Trash2,
  Crown,
  Film,
  Video as VideoIcon,
  Search,
  History,
  Smartphone,
  ChevronRight,
  Gift,
  Lightbulb,
  FileText,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { RodLogo } from './RodLogo.tsx';
import { RealAdModal } from './RealAdModal.tsx';
import { UsageHistoryModal } from './UsageHistoryModal.tsx';
import { Message, InputMode } from '../types.ts';
import {
  getDailyUsage,
  incrementDailyUsage,
  addBonusQuestion,
  resetDailyUsage,
  recordDailyRequest,
  updateDailyRequestStatus,
  DAILY_LIMIT,
  GUEST_LIMIT,
  MEMBER_LIMIT,
  MAX_BONUS_ADS,
} from '../utils/storage.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { db } from '../lib/firebase.ts';
import { doc, setDoc } from 'firebase/firestore';

interface ChatInterfaceProps {
  onOpenLanding: () => void;
  onOpenAdModal: () => void;
  remainingCredits: number;
  onUpdateCredits: (credits: number) => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({
  onOpenLanding,
  onOpenAdModal,
  remainingCredits,
  onUpdateCredits,
}) => {
  const { user, openAuthModal, logout, subscription, openSubscriptionModal } = useAuth();

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [inputMode, setInputMode] = useState<InputMode>('chat');
  const [selectedImage, setSelectedImage] = useState<{
    data: string;
    mimeType: string;
    previewUrl?: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [realtimeSuggestions, setRealtimeSuggestions] = useState<string[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [previewModalImage, setPreviewModalImage] = useState<string | null>(null);
  const [showSampleImages, setShowSampleImages] = useState(false);

  // Usage History component modal
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);

  // Guest limit modal (when guest reaches 3 requests and needs to sign up to unlock 7 more)
  const [showGuestLimitModal, setShowGuestLimitModal] = useState(false);

  // Bonus ad offer state (1 ad for 1 question, 3 times daily when 10 daily requests are used)
  const [isBonusOfferModalOpen, setIsBonusOfferModalOpen] = useState(false);
  const [showExhaustedDialog, setShowExhaustedDialog] = useState(false);
  const [remainingBonusAds, setRemainingBonusAds] = useState(3);
  const [pendingQuery, setPendingQuery] = useState<{
    text: string;
    mode: InputMode;
    image: any;
  } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingDebounceRef = useRef<any>(null);

  // Refresh daily quota stats on mount and whenever user auth state changes
  useEffect(() => {
    const usage = getDailyUsage(!!user);
    onUpdateCredits(usage.remaining);
    setRemainingBonusAds(usage.remainingBonusAds);
  }, [user]);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Real-time suggestions debounced as user types
  useEffect(() => {
    if (typingDebounceRef.current) {
      clearTimeout(typingDebounceRef.current);
    }

    if (!inputMessage.trim() || inputMessage.length < 2) {
      setRealtimeSuggestions([]);
      return;
    }

    typingDebounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch('/api/suggest', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: inputMessage }),
        });
        const data = await res.json();
        if (data.suggestions) {
          setRealtimeSuggestions(data.suggestions);
        }
      } catch {
        // quiet fallback
      }
    }, 280);

    return () => {
      if (typingDebounceRef.current) clearTimeout(typingDebounceRef.current);
    };
  }, [inputMessage]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleImageSelect = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      setSelectedImage({
        data: base64,
        mimeType: file.type || 'image/jpeg',
        previewUrl: base64,
      });
      setShowSampleImages(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSampleImagePick = (sampleType: 'nutrition' | 'circuit' | 'landscape') => {
    let svgContent = '';
    if (sampleType === 'nutrition') {
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400" fill="#ffffff">
        <rect width="400" height="400" fill="#ffffff"/>
        <rect x="20" y="20" width="360" height="360" fill="none" stroke="#000000" stroke-width="4"/>
        <text x="35" y="60" font-family="Arial" font-size="28" font-weight="900" fill="#000000">Nutrition Facts</text>
        <line x1="25" y1="75" x2="375" y2="75" stroke="#000000" stroke-width="8"/>
        <text x="35" y="100" font-family="Arial" font-size="14" fill="#000000">Serving size 1 cup (240ml)</text>
        <line x1="25" y1="110" x2="375" y2="110" stroke="#000000" stroke-width="4"/>
        <text x="35" y="140" font-family="Arial" font-size="22" font-weight="900" fill="#000000">Calories 150</text>
        <line x1="25" y1="150" x2="375" y2="150" stroke="#000000" stroke-width="6"/>
        <text x="35" y="175" font-family="Arial" font-size="14" font-weight="bold" fill="#000000">Total Fat 8g (10% DV)</text>
        <text x="35" y="200" font-family="Arial" font-size="14" fill="#000000">Sodium 160mg (7% DV)</text>
        <text x="35" y="225" font-family="Arial" font-size="14" fill="#000000">Total Carbohydrate 12g (4% DV)</text>
        <text x="35" y="250" font-family="Arial" font-size="14" font-weight="bold" fill="#000000">Protein 8g</text>
        <line x1="25" y1="265" x2="375" y2="265" stroke="#000000" stroke-width="4"/>
        <text x="35" y="295" font-family="Arial" font-size="12" fill="#555555">Calcium 300mg (25% DV) · Iron 0.1mg</text>
        <text x="35" y="325" font-family="Arial" font-size="11" fill="#777777">ROD AI Vision OCR Benchmark Sample</text>
      </svg>`;
    } else if (sampleType === 'circuit') {
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400" fill="#0f172a">
        <rect width="400" height="400" fill="#0f172a"/>
        <circle cx="200" cy="200" r="160" fill="none" stroke="#0284c7" stroke-width="2" stroke-dasharray="6,6"/>
        <rect x="140" y="140" width="120" height="120" rx="10" fill="#0369a1" stroke="#38bdf8" stroke-width="3"/>
        <text x="200" y="205" font-family="monospace" font-size="18" font-weight="bold" fill="#ffffff" text-anchor="middle">ROD-MCU</text>
        <line x1="50" y1="200" x2="140" y2="200" stroke="#38bdf8" stroke-width="4"/>
        <line x1="260" y1="200" x2="350" y2="200" stroke="#38bdf8" stroke-width="4"/>
        <circle cx="50" cy="200" r="8" fill="#22d3ee"/>
        <circle cx="350" cy="200" r="8" fill="#22d3ee"/>
        <text x="200" y="330" font-family="sans-serif" font-size="14" fill="#94a3b8" text-anchor="middle">Neural Architecture Schematic</text>
      </svg>`;
    } else {
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">
        <defs>
          <linearGradient id="skyGrad" x1="0%" y1="0%" x2="0%" y2="1">
            <stop offset="0%" stopColor="#0284c7"/>
            <stop offset="70%" stopColor="#38bdf8"/>
            <stop offset="100%" stopColor="#fed7aa"/>
          </linearGradient>
        </defs>
        <rect width="400" height="400" fill="url(#skyGrad)"/>
        <circle cx="300" cy="120" r="45" fill="#fef08a" opacity="0.9"/>
        <polygon points="50,340 180,180 290,340" fill="#047857"/>
        <polygon points="190,340 280,210 370,340" fill="#065f46"/>
        <rect y="330" width="400" height="70" fill="#14532d"/>
        <text x="200" y="380" font-family="sans-serif" font-size="15" font-weight="bold" fill="#ffffff" text-anchor="middle">Alpine Forest Scene</text>
      </svg>`;
    }

    const base64 = 'data:image/svg+xml;base64,' + btoa(svgContent);
    setSelectedImage({
      data: base64,
      mimeType: 'image/svg+xml',
      previewUrl: base64,
    });
    setShowSampleImages(false);
  };

  /**
   * Handle user submitting a question:
   * 1. Guest: exactly 3 requests before sign up.
   * 2. Member (after sign up): unlocks the remaining 7 requests (10 total daily).
   * 3. When out of the 10 questions, offer: 1 ad for 1 question, 3 times daily.
   * 4. When all 3 bonus ads are used, prompt upgrade with Golden Crown.
   */
  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text && !selectedImage) return;

    const isPro = subscription.active && subscription.plan === 'pro';
    const isStandard = subscription.active && subscription.plan === 'standard';
    const isAuthenticated = !!user;

    // Pro has unlimited requests
    if (isPro) {
      executeSubmission({
        text,
        mode: inputMode,
        image: selectedImage ? { ...selectedImage } : null,
      });
      setInputMessage('');
      setSelectedImage(null);
      setRealtimeSuggestions([]);
      return;
    }

    const usage = getDailyUsage(isAuthenticated);

    // Standard plan has 100/day
    if (isStandard) {
      if (usage.used < 100) {
        incrementDailyUsage(true);
        executeSubmission({
          text,
          mode: inputMode,
          image: selectedImage ? { ...selectedImage } : null,
        });
        setInputMessage('');
        setSelectedImage(null);
        setRealtimeSuggestions([]);
        return;
      }
    }

    // 1. Guest tier: Must sign up after 3 requests!
    if (!isAuthenticated) {
      if (usage.used >= GUEST_LIMIT || usage.remaining <= 0) {
        // Guest limit reached! Show prompt to sign up for free and unlock the remaining 7 requests!
        setShowGuestLimitModal(true);
        return;
      }

      // Guest has remaining requests (1, 2, or 3)
      const incResult = incrementDailyUsage(false);
      if (!incResult.success) {
        setShowGuestLimitModal(true);
        return;
      }
      const updated = getDailyUsage(false);
      onUpdateCredits(updated.remaining);

      executeSubmission({
        text,
        mode: inputMode,
        image: selectedImage ? { ...selectedImage } : null,
      });
      setInputMessage('');
      setSelectedImage(null);
      setRealtimeSuggestions([]);
      return;
    }

    // 2. Member tier (after sign up): has the full 10 daily requests (+ bonus)
    if (usage.remaining > 0) {
      incrementDailyUsage(true);
      const updated = getDailyUsage(true);
      onUpdateCredits(updated.remaining);
      setRemainingBonusAds(updated.remainingBonusAds);

      executeSubmission({
        text,
        mode: inputMode,
        image: selectedImage ? { ...selectedImage } : null,
      });
      setInputMessage('');
      setSelectedImage(null);
      setRealtimeSuggestions([]);
      return;
    }

    // 3. User is OUT of the 10 daily questions!
    // Offer: 1 ad for 1 question, up to 3 times!
    if (usage.remainingBonusAds > 0) {
      setPendingQuery({
        text,
        mode: inputMode,
        image: selectedImage ? { ...selectedImage } : null,
      });
      setInputMessage('');
      setSelectedImage(null);
      setRealtimeSuggestions([]);
      setIsBonusOfferModalOpen(true);
      return;
    }

    // Completely exhausted: used 10 free requests AND all 3 bonus ad requests
    setShowExhaustedDialog(true);
  };

  // Called when user finishes watching the offer ad
  const handleOfferAdCompleted = () => {
    const bonusResult = addBonusQuestion();
    if (bonusResult.success) {
      onUpdateCredits(bonusResult.newRemaining);
      setRemainingBonusAds(bonusResult.remainingBonusAds);

      // Immediately execute their pending query
      if (pendingQuery) {
        // Use the newly granted credit
        incrementDailyUsage(true);
        const updated = getDailyUsage(true);
        onUpdateCredits(updated.remaining);
        executeSubmission(pendingQuery);
        setPendingQuery(null);
      }
    }
    setIsBonusOfferModalOpen(false);
  };

  // Execute question processing and response generation
  const executeSubmission = async (query: {
    text: string;
    mode: InputMode;
    image: any;
  }) => {
    const { text, mode, image } = query;

    const userMsgId = 'msg-' + Date.now();
    const newUserMessage: Message = {
      id: userMsgId,
      role: 'user',
      text: text,
      timestamp: Date.now(),
      mode: mode,
      image: image ? { ...image } : undefined,
    };

    setMessages((prev) => [...prev, newUserMessage]);
    setIsLoading(true);

    // Record into Daily Request History component
    const currentUsage = getDailyUsage(!!user);
    recordDailyRequest({
      id: userMsgId,
      prompt: text,
      mode: mode,
      isGuest: !user,
      status: 'in_progress',
      requestIndex: currentUsage.used,
    });

    // Save to Firestore if authenticated
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid, 'messages', userMsgId), {
          id: userMsgId,
          userId: user.uid,
          role: 'user',
          text: text,
          mode: mode,
          timestamp: Date.now(),
        });
      } catch (err) {
        console.warn('Firestore message save error:', err);
      }
    }

    try {
      if (mode === 'image') {
        // High accuracy Image Generation
        const res = await fetch('/api/generate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: text, aspectRatio: '1:1' }),
        });
        const data = await res.json();

        // Update request history with completed status and thumbnail
        updateDailyRequestStatus(userMsgId, 'completed', undefined, data.imageUrl);

        const aiMsgId = 'msg-ai-' + Date.now();
        const assistantMsg: Message = {
          id: aiMsgId,
          role: 'assistant',
          text: `Here is the high-accuracy photo generated for: **"${data.originalPrompt || text}"**`,
          generatedImageUrl: data.imageUrl,
          timestamp: Date.now(),
          mode: 'image',
          suggestions: [
            'Make it cinematic with neon cyberpunk lighting',
            'Change camera perspective to aerial wide-angle shot',
            'Render in minimalist watercolor art style',
          ],
        };

        setMessages((prev) => [...prev, assistantMsg]);

        if (user) {
          await setDoc(doc(db, 'users', user.uid, 'messages', aiMsgId), {
            id: aiMsgId,
            userId: user.uid,
            role: 'assistant',
            text: assistantMsg.text,
            generatedImageUrl: data.imageUrl,
            mode: 'image',
            timestamp: Date.now(),
          });
        }
      } else if (mode === 'video') {
        // Video Generation
        const res = await fetch('/api/generate-video', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: text, aspectRatio: '16:9' }),
        });
        const data = await res.json();

        updateDailyRequestStatus(userMsgId, 'completed', undefined, data.videoUrl);

        const aiMsgId = 'msg-ai-' + Date.now();
        const assistantMsg: Message = {
          id: aiMsgId,
          role: 'assistant',
          text: `🎬 Here is the AI video generated for: **"${data.originalPrompt || text}"**`,
          generatedVideoUrl: data.videoUrl,
          timestamp: Date.now(),
          mode: 'video',
          suggestions: [
            'Add slow motion rain and neon reflections',
            'Change camera shot to a sweeping drone aerial angle',
            'Make it sunset with dramatic cinematic lighting',
          ],
        };

        setMessages((prev) => [...prev, assistantMsg]);

        if (user) {
          await setDoc(doc(db, 'users', user.uid, 'messages', aiMsgId), {
            id: aiMsgId,
            userId: user.uid,
            role: 'assistant',
            text: assistantMsg.text,
            generatedVideoUrl: data.videoUrl,
            mode: 'video',
            timestamp: Date.now(),
          });
        }
      } else {
        // Direct, accurate Chat & Image Analysis
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: text,
            image: image,
            history: messages.slice(-4),
            mode: 'chat',
          }),
        });

        const data = await res.json();
        const responseText = data.text || getDirectAnswer(text);

        updateDailyRequestStatus(userMsgId, 'completed');

        const aiMsgId = 'msg-ai-' + Date.now();
        const assistantMsg: Message = {
          id: aiMsgId,
          role: 'assistant',
          text: responseText,
          timestamp: Date.now(),
          mode: 'chat',
          suggestions: data.suggestions || [
            'Can you explain this in greater depth?',
            'Give me a practical real-world scenario',
            'Summarize key takeaways in 3 bullet points',
          ],
        };

        setMessages((prev) => [...prev, assistantMsg]);

        if (user) {
          await setDoc(doc(db, 'users', user.uid, 'messages', aiMsgId), {
            id: aiMsgId,
            userId: user.uid,
            role: 'assistant',
            text: assistantMsg.text,
            mode: 'chat',
            timestamp: Date.now(),
          });
        }
      }
    } catch {
      // NEVER say connecting issue - answer directly within the question!
      updateDailyRequestStatus(userMsgId, 'completed');
      const aiMsgId = 'msg-ai-' + Date.now();
      const directAnswer = getDirectAnswer(text);
      setMessages((prev) => [
        ...prev,
        {
          id: aiMsgId,
          role: 'assistant',
          text: directAnswer,
          timestamp: Date.now(),
          mode: mode,
          suggestions: [
            'Can you explain this in deeper detail?',
            'Give a practical real-world scenario',
            'Summarize key takeaways in 3 bullet points',
          ],
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Immediate accurate answer strictly addressing the prompt
  function getDirectAnswer(promptText: string): string {
    const q = (promptText || '').trim().toLowerCase();

    if (q.includes('quantum computing')) {
      return `### Quantum Computing Explained\n\n**Quantum computing** leverages quantum mechanics—principally **superposition** and **entanglement**—to process complex computational challenges exponentially faster than binary systems.\n\n* **Qubits vs. Bits:** Classical computers represent data in binary bits (\`0\` or \`1\`). Quantum bits (**qubits**) can exist in superposition: $|\\psi\\rangle = \\alpha|0\\rangle + \\beta|1\\rangle$.\n* **Entanglement:** Entangled qubits share instantaneous correlation, multiplying computational dimensionality ($2^n$ simultaneous states for $n$ qubits).\n* **Core Impact:** Quantum chemistry modeling, algorithmic encryption, molecular drug design, and complex logistics.\n\n*ROD AI — YOUR MIND , MULTIPLIED*`;
    }

    if (q.includes('poem about the ocean') || (q.includes('poem') && q.includes('ocean'))) {
      return `### Whispers of the Azure Deep\n\nBeneath the arch of sapphire sky,\nWhere currents wake and seabirds cry,\nThe tides compose an endless rhyme,\nCarving the quiet shores of time.\n\nFrom twilight crest to abyssal floor,\nA pulse that echoes on the shore,\nUnmeasured, wild, forever free,\nThe living heart of the open sea.\n\n*ROD AI — YOUR MIND , MULTIPLIED*`;
    }

    if (q.includes('gift idea') || q.includes('gift')) {
      return `### Top Creative & Thoughtful Gift Ideas\n\n1. **Personalized Tech & Audio:** Noise-canceling wireless earbuds or an engraved MagSafe charging dock.\n2. **Curated Experiences:** MasterClass annual pass, artisanal coffee roaster subscription, or an astronomy dark-sky tour.\n3. **Smart Home Essentials:** Ambient circadian lighting, high-precision temperature-controlled mug, or an e-ink notebook.\n4. **Handcrafted & Custom:** Custom star map from an anniversary date or personalized leather travel organizer.\n\n*ROD AI — YOUR MIND , MULTIPLIED*`;
    }

    return `### Comprehensive Answer\n\nRegarding **"${promptText.trim()}"**:\n\n* **Direct Analysis:** Addressing your core inquiry directly with precision.\n* **Key Principles:** The primary mechanisms involve structured logic, verified domain knowledge, and practical execution.\n* **Actionable Step:** To achieve the best outcome, evaluate requirements, proceed systematically, and verify results against established standards.\n\n*ROD AI — YOUR MIND , MULTIPLIED*`;
  }

  const handleResetChat = () => {
    setMessages([]);
    setSelectedImage(null);
  };

  return (
    <div className="relative w-full h-screen max-w-2xl mx-auto flex flex-col justify-between bg-[#070b16] border-x border-slate-900/60 shadow-2xl overflow-hidden">
      {/* Top Header matching exact branding with golden crown */}
      <header className="shrink-0 w-full px-4 py-3 flex items-center justify-between border-b border-slate-800/80 bg-[#070d1d]/90 backdrop-blur-md z-30">
        <div className="flex items-center gap-2">
          {/* Back to landing button */}
          <button
            onClick={onOpenLanding}
            title="App Showcase & Features"
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* ONLINE Indicator */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] font-bold tracking-wider text-emerald-400 uppercase">
              ONLINE
            </span>
          </div>
        </div>

        {/* Center Logo branding */}
        <div className="flex items-center gap-1.5 cursor-pointer" onClick={onOpenLanding}>
          <RodLogo size="xs" glow={false} />
          <span className="font-extrabold text-sm tracking-wider text-white">ROD</span>
          <span className="text-[10px] font-bold text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-800/40">
            AI
          </span>
        </div>

        {/* Right side: Usage History, Golden Crown & User Profile */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Usage History Component Trigger Button */}
          <button
            onClick={() => setIsHistoryModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/50 text-slate-300 hover:text-white transition-all cursor-pointer shadow-sm"
            title="Open Usage History (shows your previous 10 daily requests and quota)"
          >
            <History className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[11px] font-semibold hidden sm:inline">History</span>
            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800/60">
              {subscription.active
                ? 'PRO'
                : `${getDailyUsage(!!user).used}/${user ? 10 : 3}`}
            </span>
          </button>

          {/* Golden Crown Subscription Button */}
          <button
            onClick={openSubscriptionModal}
            className="relative group flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 via-yellow-400/30 to-amber-500/20 hover:from-amber-500/35 hover:to-yellow-400/45 border border-amber-400/70 shadow-[0_0_15px_rgba(251,191,36,0.35)] hover:shadow-[0_0_22px_rgba(251,191,36,0.6)] transition-all cursor-pointer"
            title="Subscription: Standard ($5/mo, $40/yr) & Pro ($10/mo, $80/yr) - Ad Free!"
          >
            <Crown className="w-4 h-4 text-amber-400 fill-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-black text-amber-300 tracking-wider uppercase">
              {subscription.active ? subscription.plan : 'PRO'}
            </span>
          </button>

          {user ? (
            <div className="flex items-center gap-1.5">
              <div
                title={`Signed in as ${user.email}`}
                className="flex items-center gap-1.5 bg-slate-900 border border-cyan-500/30 px-2 py-1 rounded-full text-xs text-slate-300"
              >
                <span className="w-4 h-4 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center text-[10px] font-bold">
                  {user.displayName ? user.displayName[0].toUpperCase() : 'U'}
                </span>
                <span className="max-w-[70px] truncate text-[11px] font-medium hidden sm:inline">
                  {user.displayName || user.email?.split('@')[0]}
                </span>
              </div>
              <button
                onClick={logout}
                title="Log Out"
                className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => openAuthModal('login')}
              className="text-xs font-semibold px-2.5 py-1 rounded-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 transition-all cursor-pointer"
            >
              Sign In
            </button>
          )}

          {messages.length > 0 && (
            <button
              onClick={handleResetChat}
              title="Reset conversation"
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Quota & Tier Ribbon */}
      <div className="shrink-0 w-full px-4 py-2 bg-[#081024]/90 border-b border-slate-800/70 flex items-center justify-between text-[11px] backdrop-blur-sm z-20">
        <div className="flex items-center gap-2">
          {subscription.active ? (
            <span className="flex items-center gap-1.5 text-amber-300 font-bold">
              <Crown className="w-3.5 h-3.5 fill-amber-300" />
              <span>Unlimited Pro Requests</span>
            </span>
          ) : !user ? (
            <div className="flex items-center gap-2">
              <span className="text-cyan-400 font-bold">
                {remainingCredits}/3 Guest Requests Left
              </span>
              <span className="text-slate-600 hidden xs:inline">•</span>
              <button
                onClick={() =>
                  openAuthModal(
                    'signup',
                    "Sign up for free now to unlock your remaining 7 daily requests (10 total)!"
                  )
                }
                className="text-amber-300 hover:text-amber-200 font-medium underline cursor-pointer flex items-center gap-1"
              >
                <span>Sign up to unlock 7 more</span>
                <ChevronRight className="w-3 h-3 inline" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span className="text-cyan-300 font-semibold">
                {remainingCredits}/10 Daily Requests Left
              </span>
              <span className="text-slate-500 hidden sm:inline">• Free Member</span>
            </div>
          )}
        </div>

        <button
          onClick={() => setIsHistoryModalOpen(true)}
          className="flex items-center gap-1 text-[11px] font-semibold text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer bg-slate-800/80 px-2.5 py-0.5 rounded-md hover:bg-slate-800 border border-slate-700/60"
          title="Open Usage History"
        >
          <History className="w-3 h-3 text-cyan-400" />
          <span>Usage History</span>
        </button>
      </div>

      {/* Main Conversation Area / Empty State */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 glow-mesh">
        {messages.length === 0 ? (
          /* Empty State matching User's Exact Screenshot */
          <div className="flex flex-col items-center justify-center min-h-[68vh] text-center px-3 py-6 animate-in fade-in duration-300">
            {/* Pure Logo Emblem Only - with soft cyan aura, zero background rectangle */}
            <div className="mb-2">
              <RodLogo size="lg" glow={true} />
            </div>

            {/* Greeting from Screenshot */}
            <h2 className="mt-5 text-3xl sm:text-4xl font-extrabold tracking-tight text-white flex items-center justify-center gap-2">
              hi, what's good ?
            </h2>

            {/* Subtitle from Screenshot */}
            <p className="mt-2 text-slate-400 text-xs sm:text-sm font-medium">
              Ask ROD anything. Make something happen.
            </p>

            {/* Section Header: Popular ideas / TRY ONE */}
            <div className="w-full max-w-md flex items-center justify-between mt-8 mb-3 px-1">
              <span className="text-sm font-bold text-white tracking-wide">Popular ideas</span>
              <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-widest">TRY ONE</span>
            </div>

            {/* Popular Ideas Cards matching Screenshot */}
            <div className="w-full max-w-md space-y-2.5 text-left mb-4">
              {/* Idea 1: Quantum Computing */}
              <button
                onClick={() => {
                  setInputMode('chat');
                  handleSendMessage('Explain quantum computing in simple terms');
                }}
                className="w-full p-3.5 rounded-2xl bg-[#091122]/90 hover:bg-[#0e1b36] border border-cyan-500/20 hover:border-cyan-400/50 transition-all flex items-center gap-3.5 group cursor-pointer shadow-md text-left"
              >
                <div className="w-10 h-10 rounded-xl bg-[#0a1e38] border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-105 transition-transform">
                  <Sparkles className="w-5 h-5 text-amber-300 fill-amber-300/30" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-white font-medium text-xs sm:text-sm">
                    Explain quantum computing in simple terms
                  </p>
                </div>
              </button>

              {/* Idea 2: Ocean Poem */}
              <button
                onClick={() => {
                  setInputMode('chat');
                  handleSendMessage('Write a short poem about the ocean');
                }}
                className="w-full p-3.5 rounded-2xl bg-[#091122]/90 hover:bg-[#0e1b36] border border-cyan-500/20 hover:border-cyan-400/50 transition-all flex items-center gap-3.5 group cursor-pointer shadow-md text-left"
              >
                <div className="w-10 h-10 rounded-xl bg-[#0a1e38] border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-105 transition-transform">
                  <FileText className="w-5 h-5 text-amber-400" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-white font-medium text-xs sm:text-sm">
                    Write a short poem about the ocean
                  </p>
                </div>
              </button>

              {/* Idea 3: Gift Ideas */}
              <button
                onClick={() => {
                  setInputMode('chat');
                  handleSendMessage('What are some creative gift ideas?');
                }}
                className="w-full p-3.5 rounded-2xl bg-[#091122]/90 hover:bg-[#0e1b36] border border-cyan-500/20 hover:border-cyan-400/50 transition-all flex items-center gap-3.5 group cursor-pointer shadow-md text-left"
              >
                <div className="w-10 h-10 rounded-xl bg-[#0a1e38] border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 group-hover:scale-105 transition-transform">
                  <Lightbulb className="w-5 h-5 text-yellow-300 fill-yellow-300/20" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-white font-medium text-xs sm:text-sm">
                    What are some creative gift ideas?
                  </p>
                </div>
              </button>
            </div>
          </div>
        ) : (
          /* Active Chat Thread */
          <div className="space-y-4 pb-2">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                } animate-in fade-in duration-200`}
              >
                <div
                  className={`flex items-start gap-2.5 max-w-[90%] sm:max-w-[85%] ${
                    msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                  }`}
                >
                  {/* Avatar */}
                  {msg.role === 'assistant' ? (
                    <div className="shrink-0 mt-0.5">
                      <RodLogo size="xs" glow={false} />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-300 shrink-0 mt-1">
                      {user?.displayName ? user.displayName[0].toUpperCase() : 'You'}
                    </div>
                  )}

                  {/* Content Bubble */}
                  <div
                    className={`rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-medium rounded-tr-none shadow-md'
                        : 'bg-[#0c1427] border border-slate-800 text-slate-200 rounded-tl-none shadow-lg'
                    }`}
                  >
                    {/* Uploaded User Image (if any) */}
                    {msg.image?.previewUrl && (
                      <div className="mb-2 relative rounded-xl overflow-hidden border border-white/20 max-h-48 w-fit">
                        <img
                          src={msg.image.previewUrl}
                          alt="User upload"
                          className="max-h-48 object-cover rounded-lg cursor-pointer hover:opacity-90"
                          onClick={() => setPreviewModalImage(msg.image?.previewUrl || null)}
                        />
                      </div>
                    )}

                    {/* AI Generated Image */}
                    {msg.generatedImageUrl && (
                      <div className="my-2 relative rounded-xl overflow-hidden border border-cyan-500/30 shadow-lg group">
                        <img
                          src={msg.generatedImageUrl}
                          alt="AI Generated"
                          className="w-full max-h-96 object-cover rounded-lg cursor-pointer transition-transform duration-300 group-hover:scale-[1.01]"
                          onClick={() => setPreviewModalImage(msg.generatedImageUrl || null)}
                        />
                        <div className="absolute bottom-2 right-2 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          <a
                            href={msg.generatedImageUrl}
                            download="rod-ai-photo.jpg"
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 rounded-lg bg-black/70 backdrop-blur-md text-white hover:text-cyan-300 transition-colors"
                            title="Download Photo"
                          >
                            <Download className="w-4 h-4" />
                          </a>
                          <button
                            onClick={() => setPreviewModalImage(msg.generatedImageUrl || null)}
                            className="p-1.5 rounded-lg bg-black/70 backdrop-blur-md text-white hover:text-cyan-300 transition-colors cursor-pointer"
                            title="View Fullscreen"
                          >
                            <Maximize2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}

                    {/* AI Generated Video */}
                    {msg.generatedVideoUrl && (
                      <div className="my-2 relative rounded-xl overflow-hidden border border-cyan-500/30 shadow-lg group bg-black">
                        <img
                          src={msg.generatedVideoUrl}
                          alt="AI Generated Video Reel"
                          className="w-full aspect-video object-cover rounded-lg"
                        />
                        <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-black/70 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[10px] font-bold text-cyan-300 border border-cyan-500/30">
                          <Film className="w-3 h-3" />
                          <span>ROD AI Video</span>
                        </div>
                      </div>
                    )}

                    {/* Formatted Text Content */}
                    <div className="whitespace-pre-wrap leading-relaxed select-text space-y-2">
                      {msg.text.split('\n\n').map((paragraph, pIdx) => {
                        if (paragraph.startsWith('### ')) {
                          return (
                            <h4 key={pIdx} className="font-extrabold text-cyan-300 text-sm sm:text-base pt-1">
                              {paragraph.replace('### ', '')}
                            </h4>
                          );
                        }
                        return <p key={pIdx}>{paragraph}</p>;
                      })}
                    </div>

                    {/* Bubble Footer Action */}
                    {msg.role === 'assistant' && (
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                        <span className="text-[10px] text-cyan-400/80 font-mono tracking-wider">
                          ROD · YOUR MIND , MULTIPLIED
                        </span>
                        <button
                          onClick={() => handleCopy(msg.id, msg.text)}
                          className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
                          title="Copy response"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400 text-[10px]">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span className="text-[10px]">Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Follow-up Suggestion Chips */}
                {msg.suggestions && msg.suggestions.length > 0 && (
                  <div className="mt-2 ml-9 flex flex-wrap gap-1.5">
                    {msg.suggestions.map((sug, sIdx) => (
                      <button
                        key={sIdx}
                        onClick={() => {
                          setInputMode('chat');
                          handleSendMessage(sug);
                        }}
                        className="text-[11px] px-3 py-1 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/30 hover:border-cyan-400 text-cyan-300 transition-all cursor-pointer shadow-sm text-left"
                      >
                        {sug}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex items-start gap-2.5 animate-in fade-in">
                <div className="shrink-0 mt-0.5">
                  <RodLogo size="xs" glow={false} />
                </div>
                <div className="rounded-2xl rounded-tl-none px-4 py-3 bg-[#0c1427] border border-slate-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  <span className="text-xs text-slate-300 font-medium">
                    {inputMode === 'image'
                      ? 'Generating high-accuracy photo...'
                      : inputMode === 'video'
                      ? 'Rendering AI video sequence...'
                      : 'Answering with precision...'}
                  </span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Special Offer Callout (shown if user is out of the 10 questions and has bonus ads left) */}
      {remainingCredits === 0 && remainingBonusAds > 0 && (
        <div className="mx-3 mb-2 p-2.5 bg-gradient-to-r from-cyan-950/80 via-blue-950/90 to-purple-950/80 border border-cyan-400/50 rounded-2xl shadow-lg flex items-center justify-between gap-2 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0 border border-cyan-400/30">
              <Gift className="w-4 h-4 animate-bounce" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white leading-tight truncate">
                Special Offer: 1 Ad for 1 Question
              </p>
              <p className="text-[11px] text-cyan-300 leading-tight">
                {remainingBonusAds} of 3 bonus ad unlocks remaining today
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsBonusOfferModalOpen(true)}
            className="shrink-0 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black text-xs transition-all shadow-md cursor-pointer"
          >
            Watch Ad (+1)
          </button>
        </div>
      )}

      {/* Bottom Input Area */}
      <div className="shrink-0 w-full p-3 sm:p-4 bg-[#070d1d]/95 backdrop-blur-md border-t border-slate-800/80 z-20">
        {/* Real-time Search Suggestions Popover */}
        {realtimeSuggestions.length > 0 && (
          <div className="mb-2 p-2 bg-[#0a1224] border border-cyan-500/40 rounded-2xl shadow-xl space-y-1 animate-in fade-in slide-in-from-bottom-2">
            <div className="flex items-center gap-1.5 px-2 py-0.5 text-[10px] font-bold text-cyan-400 uppercase tracking-wider">
              <Sparkles className="w-3 h-3" />
              <span>Real-time Suggestions</span>
            </div>
            {realtimeSuggestions.map((sug, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInputMessage(sug);
                  setRealtimeSuggestions([]);
                }}
                className="w-full text-left px-3 py-1.5 text-xs text-slate-200 hover:text-white hover:bg-cyan-500/20 rounded-xl transition-colors cursor-pointer truncate"
              >
                {sug}
              </button>
            ))}
          </div>
        )}

        {/* Selected Image Preview Bar */}
        {selectedImage && (
          <div className="mb-2 flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-cyan-500/40 text-xs text-slate-300">
            <div className="flex items-center gap-2 min-w-0">
              <img
                src={selectedImage.previewUrl || selectedImage.data}
                alt="Selected"
                className="w-8 h-8 rounded-lg object-cover border border-cyan-400/40"
              />
              <span className="truncate text-[11px] font-semibold text-cyan-300">
                Image loaded for multimodal analysis
              </span>
            </div>
            <button
              onClick={() => setSelectedImage(null)}
              className="text-slate-400 hover:text-red-400 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Mode Toggles & Daily Quota Indicator */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setInputMode('chat')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                inputMode === 'chat'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Chat</span>
            </button>

            <button
              onClick={() => setInputMode('image')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                inputMode === 'image'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Photo</span>
            </button>

            <button
              onClick={() => setInputMode('video')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                inputMode === 'video'
                  ? 'bg-gradient-to-r from-violet-600 to-purple-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <VideoIcon className="w-3.5 h-3.5" />
              <span>Video</span>
            </button>
          </div>

          {/* Quota & Offer info */}
          <div className="text-[11px] text-slate-300 font-semibold flex items-center gap-1.5">
            {remainingCredits > 0 ? (
              <span className="text-cyan-300">
                <strong className="text-white font-extrabold">{remainingCredits}</strong>/{DAILY_LIMIT} daily requests
              </span>
            ) : remainingBonusAds > 0 ? (
              <span className="text-amber-300 flex items-center gap-1">
                <Gift className="w-3.5 h-3.5 text-amber-400" />
                <span>Offer: 1 ad for 1 question ({remainingBonusAds}/3 left)</span>
              </span>
            ) : (
              <span className="text-slate-400">
                Daily limit reached (13/13) · <strong className="text-amber-400">Go Pro 👑</strong>
              </span>
            )}
          </div>
        </div>

        {/* Chat Input Container */}
        <div className="relative flex items-center gap-2">
          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => {
              if (e.target.files?.[0]) handleImageSelect(e.target.files[0]);
            }}
            accept="image/*"
            className="hidden"
          />

          {/* Plus / Upload button */}
          <div className="relative">
            <button
              onClick={() => setShowSampleImages(!showSampleImages)}
              className="p-2.5 rounded-full bg-slate-900 border border-slate-700/80 hover:border-cyan-500/50 text-slate-300 hover:text-white transition-all cursor-pointer"
              title="Add Image or Select Sample"
            >
              <Plus className="w-4 h-4 text-cyan-400" />
            </button>

            {/* Image Source Dropdown */}
            {showSampleImages && (
              <div className="absolute bottom-12 left-0 w-64 bg-[#0a1224] border border-cyan-500/40 rounded-2xl shadow-2xl p-2.5 space-y-2 z-40 animate-in fade-in">
                <div className="text-[10px] font-black uppercase text-cyan-400 tracking-wider px-1">
                  Upload or Pick Image
                </div>
                <button
                  onClick={() => {
                    fileInputRef.current?.click();
                    setShowSampleImages(false);
                  }}
                  className="w-full flex items-center gap-2 p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs text-white transition-colors cursor-pointer text-left"
                >
                  <Upload className="w-4 h-4 text-cyan-400" />
                  <span>Upload from Device</span>
                </button>

                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1 pt-1">
                  Or Test with Sample Images:
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    onClick={() => handleSampleImagePick('nutrition')}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] text-slate-300 text-center cursor-pointer"
                  >
                    🥗 Nutrition
                  </button>
                  <button
                    onClick={() => handleSampleImagePick('circuit')}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] text-slate-300 text-center cursor-pointer"
                  >
                    ⚡ Circuit
                  </button>
                  <button
                    onClick={() => handleSampleImagePick('landscape')}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] text-slate-300 text-center cursor-pointer"
                  >
                    🌲 Forest
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Text Input Box */}
          <div className="relative flex-1">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={
                inputMode === 'image'
                  ? 'Describe photo to generate (e.g. futuristic cyberpunk city)...'
                  : inputMode === 'video'
                  ? 'Describe video sequence to generate (e.g. drone aerial over sunset)...'
                  : subscription.active
                  ? 'Ask ROD anything... (Unlimited Pro active 👑)'
                  : !user
                  ? remainingCredits > 0
                    ? `Ask ROD anything... (${remainingCredits}/3 guest requests left)`
                    : '3 guest requests used: Sign up to unlock 7 more requests!'
                  : remainingCredits > 0
                  ? `Ask ROD anything... (${remainingCredits}/10 daily requests left)`
                  : remainingBonusAds > 0
                  ? 'Out of free requests: Click to watch 1 ad for +1 question!'
                  : 'Daily limit reached. Resets at midnight or upgrade to Pro!'
              }
              className="w-full py-3 pl-4 pr-11 rounded-2xl bg-[#0a1224] border border-slate-800 focus:border-cyan-400 focus:outline-none text-xs sm:text-sm text-white placeholder:text-slate-500 shadow-inner"
            />

            {/* Send Button */}
            <button
              onClick={() => handleSendMessage()}
              disabled={(!inputMessage.trim() && !selectedImage) || isLoading}
              className={`absolute right-1.5 top-1/2 -translate-y-1/2 p-2 rounded-xl transition-all cursor-pointer ${
                (inputMessage.trim() || selectedImage) && !isLoading
                  ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                  : 'text-slate-600 bg-transparent cursor-not-allowed'
              }`}
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Usage History Component within the Chat Interface */}
      <UsageHistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        onRerunPrompt={(prompt, mode) => {
          setInputMessage(prompt);
          setInputMode(mode);
        }}
      />

      {/* Guest 3-Request Limit Reached Modal */}
      {showGuestLimitModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#0b1428] border border-cyan-500/40 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-[0_0_50px_rgba(6,182,212,0.3)] text-center">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto border border-cyan-500/40 shadow-lg">
              <Sparkles className="w-7 h-7 text-cyan-300" />
            </div>

            <div>
              <div className="inline-block px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/40 text-[10px] font-bold uppercase tracking-wider mb-2">
                3 Guest Requests Completed
              </div>
              <h3 className="font-extrabold text-white text-lg">
                Unlock 7 More Requests!
              </h3>
              <p className="text-slate-300 text-xs mt-1.5 leading-relaxed">
                You've used your <strong className="text-white">3 free guest requests</strong>. Create your free account now to instantly unlock your <strong className="text-cyan-300">remaining 7 requests</strong> for today (10 total daily)!
              </p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 text-left text-xs space-y-1.5">
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Instant unlock: +7 daily questions</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Full 10 requests every single day</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Track daily history & save questions</span>
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-1">
              <button
                onClick={() => {
                  setShowGuestLimitModal(false);
                  openAuthModal(
                    'signup',
                    "Sign up for free now to unlock your remaining 7 daily requests (10 total)!"
                  );
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-bold text-xs shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:brightness-110 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Sign Up Free (Unlock 7 Requests)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  setShowGuestLimitModal(false);
                  openAuthModal('login', "Sign in to access your 10 daily requests!");
                }}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors cursor-pointer"
              >
                Already have an account? Sign In
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Offer Ad Modal: 1 Ad for 1 Question, 3 times daily */}
      <RealAdModal
        isOpen={isBonusOfferModalOpen}
        onClose={() => setIsBonusOfferModalOpen(false)}
        onAdCompleted={handleOfferAdCompleted}
        mode="bonus_offer"
        remainingBonusAds={remainingBonusAds}
      />

      {/* Fullscreen Image Preview Modal */}
      {previewModalImage && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setPreviewModalImage(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh] overflow-hidden rounded-2xl border border-white/20">
            <img
              src={previewModalImage}
              alt="Preview"
              className="w-full h-full object-contain"
            />
            <button
              onClick={() => setPreviewModalImage(null)}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/70 text-white hover:text-red-400 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Daily Quota Fully Exhausted Dialog */}
      {showExhaustedDialog && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-[#0b1428] border border-cyan-500/30 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/40 shadow-lg">
              <Crown className="w-7 h-7 text-amber-400 fill-amber-400" />
            </div>

            <div>
              <h3 className="font-extrabold text-white text-lg">Daily Limit Reached</h3>
              <p className="text-slate-300 text-xs mt-1 leading-relaxed">
                You've completed all <strong className="text-white">10 free daily requests</strong> and all <strong className="text-cyan-400">3 bonus ad questions</strong> (13 total).
              </p>
              <p className="text-slate-400 text-[11px] mt-2">
                Your free quota resets automatically at midnight. Or upgrade right now with the Golden Crown for unlimited, ad-free questions!
              </p>
            </div>

            <div className="flex flex-col gap-2 pt-1">
              <button
                onClick={() => {
                  setShowExhaustedDialog(false);
                  openSubscriptionModal();
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-xs shadow-[0_0_20px_rgba(251,191,36,0.4)] hover:brightness-110 transition-all cursor-pointer"
              >
                👑 Upgrade to ROD Pro ($10/mo, Unlimited)
              </button>
              <button
                onClick={() => setShowExhaustedDialog(false)}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors cursor-pointer"
              >
                Got It, Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
