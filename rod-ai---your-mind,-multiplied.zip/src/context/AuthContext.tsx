import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  auth,
  db,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  fbSignOut,
  updateProfile,
  onAuthStateChanged,
  syncUserProfile,
  testFirestoreConnection,
  FirebaseUser,
} from '../lib/firebase.ts';
import { doc, setDoc, getDoc } from 'firebase/firestore';

export interface SubscriptionState {
  plan: 'free' | 'standard' | 'pro';
  cycle: 'monthly' | 'annual';
  active: boolean;
  paymentMethod?: string;
  googleAccount?: string;
  orderId?: string;
  renewalDate?: string;
}

interface AuthContextType {
  user: FirebaseUser | null;
  loading: boolean;
  isAuthModalOpen: boolean;
  openAuthModal: (mode?: 'login' | 'signup', customNotice?: string) => void;
  closeAuthModal: () => void;
  authMode: 'login' | 'signup';
  setAuthMode: (mode: 'login' | 'signup') => void;
  authNotice: string | null;
  setAuthNotice: (notice: string | null) => void;
  isSubscriptionModalOpen: boolean;
  openSubscriptionModal: () => void;
  closeSubscriptionModal: () => void;
  subscription: SubscriptionState;
  updateSubscription: (
    plan: 'standard' | 'pro',
    cycle: 'monthly' | 'annual',
    paymentMethod?: string,
    googleAccount?: string,
    orderId?: string
  ) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  signupWithEmail: (email: string, pass: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUBSCRIPTION_STORAGE_KEY = 'rod_ai_subscription_v1';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [authNotice, setAuthNotice] = useState<string | null>(null);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [subscription, setSubscription] = useState<SubscriptionState>(() => {
    try {
      const stored = localStorage.getItem(SUBSCRIPTION_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return { plan: 'free', cycle: 'monthly', active: false };
  });

  useEffect(() => {
    // Validate connection once
    testFirestoreConnection();

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          await syncUserProfile(currentUser);
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists() && userDoc.data()?.subscription) {
            const remoteSub = userDoc.data().subscription;
            setSubscription(remoteSub);
            localStorage.setItem(SUBSCRIPTION_STORAGE_KEY, JSON.stringify(remoteSub));
          }
        } catch (e) {
          console.error('Failed syncing user profile or subscription:', e);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const openAuthModal = (mode: 'login' | 'signup' = 'login', customNotice?: string) => {
    setAuthMode(mode);
    setAuthNotice(customNotice || null);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
    setAuthNotice(null);
  };

  const openSubscriptionModal = () => {
    setIsSubscriptionModalOpen(true);
  };

  const closeSubscriptionModal = () => {
    setIsSubscriptionModalOpen(false);
  };

  const updateSubscription = async (
    plan: 'standard' | 'pro',
    cycle: 'monthly' | 'annual',
    paymentMethod?: string,
    googleAccount?: string,
    orderId?: string
  ) => {
    const renewalDays = cycle === 'annual' ? 365 : 30;
    const renewalDate = new Date(Date.now() + renewalDays * 24 * 60 * 60 * 1000).toISOString();
    const newSub: SubscriptionState = {
      plan,
      cycle,
      active: true,
      paymentMethod: paymentMethod || 'Google Play / Zain Iraq / oodi',
      googleAccount: googleAccount || user?.email || 'sigmachadmohame@gmail.com',
      orderId: orderId || `GPA.${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`,
      renewalDate,
    };
    setSubscription(newSub);
    localStorage.setItem(SUBSCRIPTION_STORAGE_KEY, JSON.stringify(newSub));

    if (user) {
      try {
        const userRef = doc(db, 'users', user.uid);
        await setDoc(userRef, { subscription: newSub }, { merge: true });
      } catch (err) {
        console.warn('Failed to persist subscription to Firestore:', err);
      }
    }
  };

  const loginWithGoogle = async () => {
    const cred = await signInWithPopup(auth, googleProvider);
    if (cred.user) {
      await syncUserProfile(cred.user);
      setIsAuthModalOpen(false);
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    const cred = await signInWithEmailAndPassword(auth, email, pass);
    if (cred.user) {
      await syncUserProfile(cred.user);
      setIsAuthModalOpen(false);
    }
  };

  const signupWithEmail = async (email: string, pass: string, name: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    if (cred.user) {
      if (name) {
        await updateProfile(cred.user, { displayName: name });
      }
      await syncUserProfile(cred.user);
      setIsAuthModalOpen(false);
    }
  };

  const logout = async () => {
    await fbSignOut(auth);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isAuthModalOpen,
        openAuthModal,
        closeAuthModal,
        authMode,
        setAuthMode,
        isSubscriptionModalOpen,
        openSubscriptionModal,
        closeSubscriptionModal,
        subscription,
        updateSubscription,
        loginWithGoogle,
        loginWithEmail,
        signupWithEmail,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
