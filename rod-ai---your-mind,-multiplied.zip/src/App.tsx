import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { AdRewardModal } from './components/AdRewardModal.tsx';
import { SubscriptionModal } from './components/SubscriptionModal.tsx';
import { LandingView } from './components/LandingView.tsx';
import { ChatInterface } from './components/ChatInterface.tsx';
import { getDailyUsage } from './utils/storage.ts';
import { AppView } from './types.ts';

function AppContent() {
  const { user, isSubscriptionModalOpen, closeSubscriptionModal } = useAuth();
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);
  const [remainingCredits, setRemainingCredits] = useState(3);

  useEffect(() => {
    const usage = getDailyUsage(!!user);
    setRemainingCredits(usage.remaining);
  }, [user]);

  return (
    <main className="min-h-screen w-full bg-[#050813] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {currentView === 'landing' ? (
        <LandingView
          onStartChat={() => setCurrentView('chat')}
          remainingCredits={remainingCredits}
        />
      ) : (
        <ChatInterface
          onOpenLanding={() => setCurrentView('landing')}
          onOpenAdModal={() => setIsAdModalOpen(true)}
          remainingCredits={remainingCredits}
          onUpdateCredits={(newCredits) => setRemainingCredits(newCredits)}
        />
      )}

      {/* Global Modals */}
      <AuthModal />
      <SubscriptionModal
        isOpen={isSubscriptionModalOpen}
        onClose={closeSubscriptionModal}
      />
      <AdRewardModal
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        onRewardClaimed={(newCredits) => setRemainingCredits(newCredits)}
      />
    </main>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
