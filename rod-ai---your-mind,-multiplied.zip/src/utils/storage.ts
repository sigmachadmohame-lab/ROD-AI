import { DailyUsage, DailyRequestItem, InputMode } from '../types.ts';

export const GUEST_LIMIT = 3;
export const MEMBER_LIMIT = 10;
export const DAILY_LIMIT = MEMBER_LIMIT; // Backward compatibility alias
export const MAX_BONUS_ADS = 3;

const USAGE_STORAGE_KEY = 'rod_ai_daily_usage_v2';
const HISTORY_STORAGE_KEY = 'rod_ai_daily_history_v1';

export function getTodayString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export interface DailyUsageInfo {
  used: number;
  baseLimit: number;
  guestLimit: number;
  memberLimit: number;
  effectiveLimit: number;
  isAuthenticated: boolean;
  requiresSignUpForMore: boolean;
  unlockedOnSignUp: number;
  bonusEarned: number;
  maxBonusAds: number;
  remainingBonusAds: number;
  remaining: number;
  totalLimit: number;
  date: string;
  isDailyBaseExhausted: boolean;
  canWatchAdForBonus: boolean;
  isCompletelyExhausted: boolean;
}

export function getDailyUsage(isAuthenticated: boolean = false): DailyUsageInfo {
  const today = getTodayString();
  let used = 0;
  let bonusEarned = 0;

  try {
    const raw = localStorage.getItem(USAGE_STORAGE_KEY);
    if (raw) {
      const data: DailyUsage = JSON.parse(raw);
      if (data.date === today) {
        used = typeof data.used === 'number' ? data.used : 0;
        bonusEarned = Math.min(MAX_BONUS_ADS, data.bonusEarned || 0);
      } else {
        // New day: reset storage
        const resetData: DailyUsage = { date: today, used: 0, bonusEarned: 0 };
        localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify(resetData));
      }
    } else {
      const initialData: DailyUsage = { date: today, used: 0, bonusEarned: 0 };
      localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify(initialData));
    }
  } catch (e) {
    console.error('Failed reading daily usage', e);
  }

  // Quota calculation based on authentication status:
  // - Guest (unauthenticated): exactly 3 requests
  // - Member (authenticated): 10 requests daily (+ bonus earned)
  // - If guest used 3 requests and signs up, they get the remaining 7 requests (total 10)
  const effectiveLimit = isAuthenticated ? (MEMBER_LIMIT + bonusEarned) : GUEST_LIMIT;
  const remaining = Math.max(0, effectiveLimit - used);
  const remainingBonusAds = Math.max(0, MAX_BONUS_ADS - bonusEarned);
  
  // Flag indicating if a guest reached their 3 requests limit and needs to sign up to unlock 7 more
  const requiresSignUpForMore = !isAuthenticated && used >= GUEST_LIMIT;
  const unlockedOnSignUp = Math.max(0, MEMBER_LIMIT - used);

  const isDailyBaseExhausted = used >= MEMBER_LIMIT;
  const canWatchAdForBonus = isAuthenticated && isDailyBaseExhausted && remaining === 0 && remainingBonusAds > 0;
  const isCompletelyExhausted = isAuthenticated && remaining === 0 && remainingBonusAds === 0;

  return {
    used,
    baseLimit: MEMBER_LIMIT,
    guestLimit: GUEST_LIMIT,
    memberLimit: MEMBER_LIMIT,
    effectiveLimit,
    isAuthenticated,
    requiresSignUpForMore,
    unlockedOnSignUp,
    bonusEarned,
    maxBonusAds: MAX_BONUS_ADS,
    remainingBonusAds,
    remaining,
    totalLimit: effectiveLimit,
    date: today,
    isDailyBaseExhausted,
    canWatchAdForBonus,
    isCompletelyExhausted,
  };
}

export function incrementDailyUsage(isAuthenticated: boolean = false): { success: boolean; requiresSignUp: boolean } {
  const current = getDailyUsage(isAuthenticated);

  // If user is guest and already used GUEST_LIMIT (3), block and prompt sign up
  if (!isAuthenticated && current.used >= GUEST_LIMIT) {
    return { success: false, requiresSignUp: true };
  }

  if (current.remaining <= 0) {
    return { success: false, requiresSignUp: false };
  }

  const updated: DailyUsage = {
    date: current.date,
    used: current.used + 1,
    bonusEarned: current.bonusEarned,
  };

  localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify(updated));
  return { success: true, requiresSignUp: false };
}

export function addBonusQuestion(): { success: boolean; newRemaining: number; remainingBonusAds: number } {
  const current = getDailyUsage(true);
  if (current.bonusEarned >= MAX_BONUS_ADS) {
    return {
      success: false,
      newRemaining: current.remaining,
      remainingBonusAds: 0,
    };
  }

  const updated: DailyUsage = {
    date: current.date,
    used: current.used,
    bonusEarned: current.bonusEarned + 1,
  };
  localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify(updated));

  const newTotal = MEMBER_LIMIT + updated.bonusEarned;
  const newRemaining = Math.max(0, newTotal - updated.used);
  const remainingBonusAds = Math.max(0, MAX_BONUS_ADS - updated.bonusEarned);

  return {
    success: true,
    newRemaining,
    remainingBonusAds,
  };
}

export function resetDailyUsage(): void {
  const today = getTodayString();
  const reset: DailyUsage = {
    date: today,
    used: 0,
    bonusEarned: 0,
  };
  localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify(reset));
}

// ==========================================
// Daily Request History Management (Up to 10 requests)
// ==========================================

interface StoredDailyHistory {
  date: string;
  requests: DailyRequestItem[];
}

export function getDailyRequestHistory(): DailyRequestItem[] {
  const today = getTodayString();
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (raw) {
      const data: StoredDailyHistory = JSON.parse(raw);
      if (data.date === today && Array.isArray(data.requests)) {
        return data.requests;
      }
    }
  } catch (e) {
    console.error('Failed reading request history', e);
  }
  return [];
}

export function recordDailyRequest(params: {
  id: string;
  prompt: string;
  mode: InputMode;
  isGuest: boolean;
  status?: 'in_progress' | 'completed' | 'failed';
  requestIndex?: number;
  previewImageUrl?: string;
}): DailyRequestItem {
  const today = getTodayString();
  const history = getDailyRequestHistory();
  const nextIndex = params.requestIndex || (history.length + 1);

  let tierLabel = 'Guest Free (1-3)';
  if (!params.isGuest) {
    if (nextIndex <= 3) {
      tierLabel = 'Standard (1-3)';
    } else if (nextIndex <= 10) {
      tierLabel = 'Member Unlocked (4-10)';
    } else {
      tierLabel = 'Bonus Ad Request';
    }
  } else {
    tierLabel = `Guest Free (${nextIndex}/3)`;
  }

  const newItem: DailyRequestItem = {
    id: params.id,
    prompt: params.prompt,
    mode: params.mode,
    timestamp: Date.now(),
    status: params.status || 'in_progress',
    isGuest: params.isGuest,
    requestIndex: nextIndex,
    tierLabel,
    previewImageUrl: params.previewImageUrl,
  };

  // Keep all requests of today (showing the previous daily requests)
  const updatedRequests = [newItem, ...history.filter((r) => r.id !== params.id)];

  try {
    const payload: StoredDailyHistory = {
      date: today,
      requests: updatedRequests,
    };
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(payload));
  } catch (e) {
    console.error('Failed saving request history', e);
  }

  return newItem;
}

export function updateDailyRequestStatus(
  id: string,
  status: 'completed' | 'failed',
  error?: string,
  previewImageUrl?: string
): void {
  const today = getTodayString();
  const history = getDailyRequestHistory();
  const updated = history.map((item) => {
    if (item.id === id) {
      return {
        ...item,
        status,
        error: error || item.error,
        previewImageUrl: previewImageUrl || item.previewImageUrl,
      };
    }
    return item;
  });

  try {
    const payload: StoredDailyHistory = {
      date: today,
      requests: updated,
    };
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(payload));
  } catch (e) {
    console.error('Failed updating request history', e);
  }
}

export function clearDailyHistory(): void {
  const today = getTodayString();
  const payload: StoredDailyHistory = {
    date: today,
    requests: [],
  };
  localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(payload));
}
